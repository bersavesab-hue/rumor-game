extends Control

const NpcActorScene = preload("res://scripts/npc_actor.gd")

var engine := RumorEngine.new()
var rng := RandomNumberGenerator.new()
var npcs: Array = []
var actors: Dictionary = {}
var intel_list: Array = []
var selected_npc_id: int = 0
var state := {
	"cash": 1200,
	"ap": 6,
	"minute": 8 * 60,
	"day": 1,
	"paused": false,
	"speed": 1,
	"last_intel_refresh_day": 1,
}

var root_bg: ColorRect
var map_panel: PanelContainer
var map_area: Control
var npc_layer: Control
var top_time: Label
var top_cash: Label
var top_ap: Label
var rumor_subject: Label
var rumor_domain: Label
var rumor_text: Label
var heat_bar: ProgressBar
var trace_bar: ProgressBar
var exposure_bar: ProgressBar
var heat_value: Label
var trace_value: Label
var exposure_value: Label
var spread_button: Button
var cool_button: Button
var decoy_button: Button
var trace_button: Button
var selected_hint: Label
var overlay: ColorRect
var sheet: PanelContainer
var sheet_title: Label
var sheet_body: VBoxContainer
var event_panel: PanelContainer
var event_title: Label
var event_text: Label
var sim_timer: Timer
var event_hide_timer: Timer

var colors := {
	"bg": Color("#151c1f"),
	"top": Color("#20282a"),
	"map": Color("#aac493"),
	"road": Color("#d8c9ad"),
	"paper": Color("#f7f0e1"),
	"paper2": Color("#eee2cc"),
	"ink": Color("#292521"),
	"muted": Color("#736a5e"),
	"line": Color("#c7b496"),
	"accent": Color("#d3913e"),
	"danger": Color("#b85046"),
	"blue": Color("#527b92"),
	"green": Color("#557d61"),
}

func _ready() -> void:
	rng.randomize()
	_setup_theme()
	_build_ui()
	_generate_npcs(96)
	_refresh_intel()
	await get_tree().process_frame
	_create_npc_actors()
	_refresh_all()
	_start_simulation()
	_show_event("欢迎来到小镇", "这次是原生 Godot 版本。先点地图人物，再从“情报”里选择一条消息。")

func _setup_theme() -> void:
	var system_font := SystemFont.new()
	system_font.font_names = PackedStringArray(["Noto Sans CJK SC", "Noto Sans SC", "Noto Sans", "sans-serif"])
	system_font.font_weight = 500
	var game_theme := Theme.new()
	game_theme.default_font = system_font
	game_theme.default_font_size = 14
	theme = game_theme

func _build_ui() -> void:
	root_bg = ColorRect.new()
	root_bg.color = colors.bg
	root_bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(root_bg)

	var main_v := VBoxContainer.new()
	main_v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	main_v.add_theme_constant_override("separation", 0)
	add_child(main_v)

	_build_topbar(main_v)
	_build_stage(main_v)
	_build_bottom_nav(main_v)
	_build_sheet_overlay()
	_build_event_banner()

func _build_topbar(parent: VBoxContainer) -> void:
	var top := PanelContainer.new()
	top.custom_minimum_size = Vector2(0, 64)
	top.add_theme_stylebox_override("panel", _style(colors.top, 0, Color.TRANSPARENT, 0))
	parent.add_child(top)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 12)
	margin.add_theme_constant_override("margin_right", 12)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	top.add_child(margin)

	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	row.add_theme_constant_override("separation", 8)
	margin.add_child(row)

	var mark := Label.new()
	mark.text = "传"
	mark.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mark.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	mark.custom_minimum_size = Vector2(38, 38)
	mark.add_theme_color_override("font_color", colors.ink)
	mark.add_theme_font_size_override("font_size", 20)
	mark.add_theme_stylebox_override("normal", _style(Color("#ead7b5"), 11, Color.TRANSPARENT, 0))
	row.add_child(mark)

	var title_box := VBoxContainer.new()
	title_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_box.add_theme_constant_override("separation", -1)
	row.add_child(title_box)
	var title := Label.new()
	title.text = "这消息谁传的？"
	title.add_theme_color_override("font_color", Color.WHITE)
	title.add_theme_font_size_override("font_size", 16)
	title_box.add_child(title)
	var sub := Label.new()
	sub.text = "信息操盘 · 小镇沙盒"
	sub.add_theme_color_override("font_color", Color("#aeb9bb"))
	sub.add_theme_font_size_override("font_size", 9)
	title_box.add_child(sub)

	var stats := HBoxContainer.new()
	stats.add_theme_constant_override("separation", 5)
	row.add_child(stats)
	top_time = _top_chip(stats, "08:00", "时间")
	top_cash = _top_chip(stats, "¥1200", "资金")
	top_ap = _top_chip(stats, "6", "行动")

func _top_chip(parent: Control, value: String, caption: String) -> Label:
	var p := PanelContainer.new()
	p.custom_minimum_size = Vector2(52, 40)
	p.add_theme_stylebox_override("panel", _style(Color("#ffffff12"), 9, Color("#ffffff18"), 1))
	parent.add_child(p)
	var v := VBoxContainer.new()
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", -3)
	p.add_child(v)
	var val := Label.new()
	val.text = value
	val.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	val.add_theme_color_override("font_color", Color.WHITE)
	val.add_theme_font_size_override("font_size", 11)
	v.add_child(val)
	var cap := Label.new()
	cap.text = caption
	cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	cap.add_theme_color_override("font_color", Color("#b4bec0"))
	cap.add_theme_font_size_override("font_size", 8)
	v.add_child(cap)
	return val

func _build_stage(parent: VBoxContainer) -> void:
	var stage := Control.new()
	stage.size_flags_vertical = Control.SIZE_EXPAND_FILL
	stage.clip_contents = true
	parent.add_child(stage)

	map_panel = PanelContainer.new()
	map_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	map_panel.add_theme_stylebox_override("panel", _style(colors.map, 0, Color.TRANSPARENT, 0))
	stage.add_child(map_panel)
	map_area = Control.new()
	map_area.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	map_panel.add_child(map_area)
	_build_map_background(map_area)

	npc_layer = Control.new()
	npc_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	npc_layer.mouse_filter = Control.MOUSE_FILTER_PASS
	map_area.add_child(npc_layer)

	var rumor_card := PanelContainer.new()
	rumor_card.anchor_left = 0.025
	rumor_card.anchor_right = 0.975
	rumor_card.anchor_top = 0.66
	rumor_card.anchor_bottom = 0.985
	rumor_card.add_theme_stylebox_override("panel", _style(Color("#f8f2e6f2"), 16, Color("#bba98b"), 1))
	stage.add_child(rumor_card)
	var rm := MarginContainer.new()
	for side in ["left","right","top","bottom"]:
		rm.add_theme_constant_override("margin_" + side, 10)
	rumor_card.add_child(rm)
	var rv := VBoxContainer.new()
	rv.add_theme_constant_override("separation", 5)
	rm.add_child(rv)

	var head := HBoxContainer.new()
	rv.add_child(head)
	rumor_subject = Label.new()
	rumor_subject.text = "暂无活跃消息"
	rumor_subject.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rumor_subject.add_theme_font_size_override("font_size", 13)
	rumor_subject.add_theme_color_override("font_color", colors.ink)
	head.add_child(rumor_subject)
	rumor_domain = Label.new()
	rumor_domain.text = "等待"
	rumor_domain.add_theme_font_size_override("font_size", 9)
	rumor_domain.add_theme_color_override("font_color", Color("#3f6070"))
	rumor_domain.add_theme_stylebox_override("normal", _style(Color("#d9e7eb"), 8, Color.TRANSPARENT, 0))
	head.add_child(rumor_domain)

	rumor_text = Label.new()
	rumor_text.text = "从“情报”里选一条消息。先判断值不值得碰，再决定调查还是扩散。"
	rumor_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rumor_text.add_theme_font_size_override("font_size", 10)
	rumor_text.add_theme_color_override("font_color", colors.ink)
	rv.add_child(rumor_text)

	var metrics := GridContainer.new()
	metrics.columns = 3
	metrics.add_theme_constant_override("h_separation", 6)
	metrics.add_theme_constant_override("v_separation", 3)
	rv.add_child(metrics)
	var triplet = _metric_row(metrics, "热度", colors.accent)
	heat_bar = triplet[0]; heat_value = triplet[1]
	triplet = _metric_row(metrics, "追查", colors.blue)
	trace_bar = triplet[0]; trace_value = triplet[1]
	triplet = _metric_row(metrics, "暴露", colors.danger)
	exposure_bar = triplet[0]; exposure_value = triplet[1]

	selected_hint = Label.new()
	selected_hint.text = "当前人物：未选择"
	selected_hint.add_theme_font_size_override("font_size", 9)
	selected_hint.add_theme_color_override("font_color", colors.muted)
	rv.add_child(selected_hint)

	var actions := HBoxContainer.new()
	actions.add_theme_constant_override("separation", 6)
	rv.add_child(actions)
	spread_button = _action_button(actions, "推给此人", true)
	spread_button.pressed.connect(_on_manual_spread)
	cool_button = _action_button(actions, "主动降温")
	cool_button.pressed.connect(_on_cool_down)
	trace_button = _action_button(actions, "查看追查")
	trace_button.pressed.connect(func(): _open_sheet("trace"))
	decoy_button = _action_button(actions, "制造假线索")
	decoy_button.pressed.connect(_on_decoy)

func _build_map_background(parent: Control) -> void:
	# 两横两竖道路。
	for data in [
		[Vector2(0,0.285), Vector2(1,0.07)], [Vector2(0,0.595), Vector2(1,0.07)],
		[Vector2(0.295,0), Vector2(0.08,1)], [Vector2(0.625,0), Vector2(0.08,1)]
	]:
		var road := ColorRect.new()
		road.color = colors.road
		road.anchor_left = data[0].x
		road.anchor_top = data[0].y
		road.anchor_right = data[0].x + data[1].x
		road.anchor_bottom = data[0].y + data[1].y
		parent.add_child(road)

	var info = [
		["market","东门市场","🥬",Color("#e2c78f")], ["bank","安泰银行","🏦",Color("#cdd9c4")], ["media","融媒体","📺",Color("#d7c4db")],
		["home","幸福小区","🏘",Color("#d8bea9")], ["tea","老街茶馆","☕",Color("#d2c19f")], ["factory","金海食品厂","🏭",Color("#c5d6dd")],
		["school","城南小学","🏫",Color("#e0cec2")], ["mall","商业街","🛍",Color("#d5ddb9")], ["office","新区写字楼","🏢",Color("#c9c3df")]
	]
	var points := DomainData.district_points()
	for item in info:
		var panel := PanelContainer.new()
		var p: Vector2 = points[item[0]]
		panel.anchor_left = p.x - 0.105
		panel.anchor_right = p.x + 0.105
		panel.anchor_top = p.y - 0.075
		panel.anchor_bottom = p.y + 0.075
		panel.add_theme_stylebox_override("panel", _style(item[3], 11, Color("#655b50"), 2))
		parent.add_child(panel)
		var label := Label.new()
		label.text = "%s\n%s" % [item[2], item[1]]
		label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		label.add_theme_font_size_override("font_size", 10)
		label.add_theme_color_override("font_color", colors.ink)
		panel.add_child(label)

func _metric_row(parent: GridContainer, caption: String, color: Color) -> Array:
	var cap := Label.new(); cap.text = caption; cap.add_theme_font_size_override("font_size", 9); cap.add_theme_color_override("font_color", colors.muted); parent.add_child(cap)
	var bar := ProgressBar.new(); bar.min_value = 0; bar.max_value = 100; bar.value = 0; bar.show_percentage = false; bar.custom_minimum_size = Vector2(0, 7); bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bar.add_theme_stylebox_override("background", _style(Color("#ded2bf"), 6, Color.TRANSPARENT, 0))
	bar.add_theme_stylebox_override("fill", _style(color, 6, Color.TRANSPARENT, 0)); parent.add_child(bar)
	var val := Label.new(); val.text = "0"; val.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT; val.add_theme_font_size_override("font_size", 9); val.add_theme_color_override("font_color", colors.ink); parent.add_child(val)
	return [bar, val]

func _action_button(parent: Control, label_text: String, primary: bool = false) -> Button:
	var b := Button.new()
	b.text = label_text
	b.focus_mode = Control.FOCUS_NONE
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_font_size_override("font_size", 9)
	var bg := Color("#f8ead4") if primary else Color("#fffaf0")
	var border := Color("#b78951") if primary else colors.line
	b.add_theme_stylebox_override("normal", _style(bg, 9, border, 1))
	b.add_theme_stylebox_override("hover", _style(bg.lightened(0.04), 9, border, 1))
	b.add_theme_stylebox_override("pressed", _style(bg.darkened(0.05), 9, border, 1))
	b.add_theme_color_override("font_color", colors.ink)
	parent.add_child(b)
	return b

func _build_bottom_nav(parent: VBoxContainer) -> void:
	var nav := PanelContainer.new()
	nav.custom_minimum_size = Vector2(0, 68)
	nav.add_theme_stylebox_override("panel", _style(colors.top, 0, Color("#ffffff12"), 1))
	parent.add_child(nav)
	var row := HBoxContainer.new()
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	nav.add_child(row)
	for item in [["镇","小镇","town"],["讯","情报","intel"],["网","关系","network"],["查","追查","trace"],["人","人物","profile"]]:
		var b := Button.new()
		b.text = "%s\n%s" % [item[0], item[1]]
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.focus_mode = Control.FOCUS_NONE
		b.add_theme_font_size_override("font_size", 9)
		b.add_theme_color_override("font_color", Color("#c2cbcd"))
		b.add_theme_stylebox_override("normal", _style(Color.TRANSPARENT, 0, Color.TRANSPARENT, 0))
		b.add_theme_stylebox_override("pressed", _style(Color("#ffffff10"), 8, Color.TRANSPARENT, 0))
		var tab: String = item[2]
		b.pressed.connect(func():
			if tab == "town":
				_close_sheet()
			else:
				_open_sheet(tab)
		)
		row.add_child(b)

func _build_sheet_overlay() -> void:
	overlay = ColorRect.new()
	overlay.color = Color("#0a0d0e88")
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.visible = false
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(overlay)

	sheet = PanelContainer.new()
	sheet.anchor_left = 0.0
	sheet.anchor_right = 1.0
	sheet.anchor_top = 0.22
	sheet.anchor_bottom = 1.0
	sheet.add_theme_stylebox_override("panel", _style(colors.paper, 20, Color("#c5b294"), 1))
	overlay.add_child(sheet)
	var vm := VBoxContainer.new()
	vm.add_theme_constant_override("separation", 0)
	sheet.add_child(vm)
	var sh := PanelContainer.new()
	sh.custom_minimum_size = Vector2(0, 52)
	sh.add_theme_stylebox_override("panel", _style(colors.paper2, 18, Color.TRANSPARENT, 0))
	vm.add_child(sh)
	var hm := MarginContainer.new()
	hm.add_theme_constant_override("margin_left", 12); hm.add_theme_constant_override("margin_right", 10); hm.add_theme_constant_override("margin_top", 8); hm.add_theme_constant_override("margin_bottom", 8)
	sh.add_child(hm)
	var hr := HBoxContainer.new(); hm.add_child(hr)
	sheet_title = Label.new(); sheet_title.text = "面板"; sheet_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL; sheet_title.add_theme_font_size_override("font_size", 15); sheet_title.add_theme_color_override("font_color", colors.ink); hr.add_child(sheet_title)
	var close := Button.new(); close.text = "关闭"; close.add_theme_font_size_override("font_size", 10); close.add_theme_stylebox_override("normal", _style(Color("#494641"), 8, Color.TRANSPARENT, 0)); close.add_theme_color_override("font_color", Color.WHITE); close.pressed.connect(_close_sheet); hr.add_child(close)

	var scroll := ScrollContainer.new(); scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL; vm.add_child(scroll)
	var body_margin := MarginContainer.new(); body_margin.add_theme_constant_override("margin_left", 10); body_margin.add_theme_constant_override("margin_right", 10); body_margin.add_theme_constant_override("margin_top", 10); body_margin.add_theme_constant_override("margin_bottom", 28); scroll.add_child(body_margin)
	sheet_body = VBoxContainer.new(); sheet_body.size_flags_horizontal = Control.SIZE_EXPAND_FILL; sheet_body.add_theme_constant_override("separation", 8); body_margin.add_child(sheet_body)

func _build_event_banner() -> void:
	event_panel = PanelContainer.new()
	event_panel.anchor_left = 0.03; event_panel.anchor_right = 0.97; event_panel.anchor_top = 0.075; event_panel.anchor_bottom = 0.16
	event_panel.add_theme_stylebox_override("panel", _style(Color("#252d2ef2"), 12, Color("#ffffff18"), 1))
	event_panel.visible = false
	add_child(event_panel)
	var m := MarginContainer.new(); m.add_theme_constant_override("margin_left", 10); m.add_theme_constant_override("margin_right", 10); m.add_theme_constant_override("margin_top", 7); m.add_theme_constant_override("margin_bottom", 7); event_panel.add_child(m)
	var v := VBoxContainer.new(); v.add_theme_constant_override("separation", 1); m.add_child(v)
	event_title = Label.new(); event_title.add_theme_font_size_override("font_size", 11); event_title.add_theme_color_override("font_color", Color.WHITE); v.add_child(event_title)
	event_text = Label.new(); event_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; event_text.add_theme_font_size_override("font_size", 9); event_text.add_theme_color_override("font_color", Color("#d7dfe0")); v.add_child(event_text)
	event_hide_timer = Timer.new(); event_hide_timer.one_shot = true; event_hide_timer.wait_time = 3.6; event_hide_timer.timeout.connect(func(): event_panel.visible = false); add_child(event_hide_timer)

func _generate_npcs(count: int) -> void:
	npcs.clear()
	var points := DomainData.district_points()
	var names := DomainData.names()
	var jobs_map := DomainData.jobs_by_district()
	var district_keys: Array = points.keys()
	for i in count:
		var d: String = district_keys[i % district_keys.size()]
		var p: Vector2 = points[d]
		var n := {
			"id": i,
			"name": names[i % names.size()] + ("" if i < names.size() else str(2 + i / names.size())),
			"district": d,
			"job": jobs_map[d][rng.randi_range(0, jobs_map[d].size()-1)],
			"map_pos": Vector2(clampf(p.x + rng.randf_range(-0.07,0.07),0.03,0.97), clampf(p.y + rng.randf_range(-0.06,0.06),0.03,0.96)),
			"talk": rng.randi_range(20, 94),
			"skeptic": rng.randi_range(20, 95),
			"influence": rng.randi_range(18, 90),
			"traits": _sample_strings(DomainData.trait_pool(), 2),
			"social": _sample_strings(DomainData.social_pool(), 2),
			"friends": [],
			"heard": false,
			"belief": 0.0,
			"node": "",
			"last_spread": -9999,
			"spread_wait": rng.randi_range(30, 65),
			"rumor_depth": 0,
			"trace_aware": false,
		}
		npcs.append(n)
	for npc in npcs:
		var friend_ids: Array = []
		while friend_ids.size() < 4:
			var id := rng.randi_range(0, npcs.size()-1)
			if id != npc["id"] and not friend_ids.has(id):
				friend_ids.append(id)
		npc["friends"] = friend_ids

func _create_npc_actors() -> void:
	for child in npc_layer.get_children(): child.queue_free()
	actors.clear()
	for npc in npcs:
		var actor := NpcActor.new()
		npc_layer.add_child(actor)
		actor.setup(npc["id"], npc["name"], _npc_pixel_position(npc), _district_color(npc["district"]))
		actor.npc_tapped.connect(_on_npc_tapped)
		actors[npc["id"]] = actor

func _npc_pixel_position(npc: Dictionary) -> Vector2:
	return Vector2(float(npc["map_pos"].x) * maxf(map_area.size.x, 432.0), float(npc["map_pos"].y) * maxf(map_area.size.y, 600.0))

func _district_color(d: String) -> Color:
	var table := {"market":"#f4dfaf","bank":"#e1ecd9","media":"#eaddec","home":"#ead5c6","tea":"#ead9b9","factory":"#d7e8ee","school":"#f0ddd3","mall":"#e6eccb","office":"#dcd7ef"}
	return Color(table.get(d, "#f8f0df"))

func _refresh_intel() -> void:
	intel_list = []
	var pool := DomainData.intel_pool().duplicate(true)
	pool.shuffle()
	for i in mini(4, pool.size()):
		var item: Dictionary = pool[i].duplicate(true)
		item["confidence"] = rng.randi_range(35, 79)
		item["age"] = 0
		intel_list.append(item)

func _start_simulation() -> void:
	sim_timer = Timer.new()
	sim_timer.wait_time = 0.85
	sim_timer.timeout.connect(_on_sim_tick)
	add_child(sim_timer)
	sim_timer.start()

func _on_sim_tick() -> void:
	if state["paused"]:
		return
	state["minute"] += 3 * int(state["speed"])
	if state["minute"] >= 24 * 60:
		state["minute"] -= 24 * 60
		state["day"] += 1
		state["ap"] = mini(9, int(state["ap"]) + 4)
		if int(state["last_intel_refresh_day"]) != int(state["day"]):
			_refresh_intel(); state["last_intel_refresh_day"] = state["day"]
		_show_event("新的一天", "行动点恢复 4 点，情报市场也刷新了。")
	if engine.has_active():
		var spread_event := engine.auto_spread_step(npcs, state["minute"])
		if not spread_event.is_empty():
			_on_spread_event(spread_event)
		var trace_event := engine.trace_step(npcs, state["minute"])
		if not trace_event.is_empty():
			_on_trace_event(trace_event)
		engine.passive_decay()
	_move_some_npcs()
	_refresh_all()

func _move_some_npcs() -> void:
	if rng.randf() > 0.20:
		return
	var points := DomainData.district_points()
	for j in 3:
		var npc: Dictionary = npcs[rng.randi_range(0, npcs.size()-1)]
		var p: Vector2 = points[npc["district"]]
		npc["map_pos"] = Vector2(clampf(p.x + rng.randf_range(-0.075,0.075),0.03,0.97), clampf(p.y + rng.randf_range(-0.065,0.065),0.03,0.96))
		if actors.has(npc["id"]): actors[npc["id"]].move_to(_npc_pixel_position(npc))

func _on_npc_tapped(id: int) -> void:
	selected_npc_id = id
	_refresh_actor_states()
	_refresh_selected_hint()
	# 轻触只选中，玩家可再点“推给此人”。

func _on_manual_spread() -> void:
	if not engine.has_active():
		_show_event("还没有消息", "先从底部“情报”里选一条消息。")
		return
	if int(state["ap"]) < 1:
		_show_event("行动点不足", "等到第二天恢复，或者先观察自然传播。")
		return
	var result := engine.manual_spread(npcs, selected_npc_id, state["minute"])
	if not result.get("ok", false):
		_show_event("这次没推成", result.get("reason", "无法传播"))
		return
	state["ap"] -= 1
	_show_event("消息迈出一跳", "%s 听到了消息。现在不会立刻连锁扩散，你有时间观察。" % npcs[selected_npc_id]["name"])
	_spawn_speech_bubble(selected_npc_id, result["wording"])
	_refresh_all()

func _on_cool_down() -> void:
	if not engine.has_active(): return
	if int(state["ap"]) < 1:
		_show_event("行动点不足", "降温需要 1 点行动。")
		return
	state["ap"] -= 1
	engine.cool_down()
	_show_event("主动降温", "你停止推送，热度下降，追查压力也略有缓解。")
	_refresh_all()

func _on_decoy() -> void:
	if not engine.has_active(): return
	if int(state["ap"]) < 2 or int(state["cash"]) < 120:
		_show_event("资源不足", "假线索需要 2 行动点和 ¥120。")
		return
	state["ap"] -= 2; state["cash"] -= 120
	engine.plant_decoy()
	_show_event("假线索已放出", "源头暴露下降，但调查者会意识到有人在主动干预。")
	_refresh_all()

func _on_spread_event(event: Dictionary) -> void:
	var target_id := int(event.get("target", -1))
	if target_id >= 0:
		_spawn_speech_bubble(target_id, event.get("wording", ""))
	if event.get("changed", false):
		var label := _active_node_label(event.get("node", ""))
		_show_event("说法发生变化", "%s 把消息推进成了“%s”。" % [npcs[target_id]["name"], label])

func _on_trace_event(event: Dictionary) -> void:
	match event.get("kind", ""):
		"investigator":
			_show_event("有人开始追查", event.get("text", "追查开始"))
		"clue":
			var clue: Dictionary = event.get("clue", {})
			_show_event("追查推进", "调查者利用【%s】往源头靠近。" % clue.get("type", "线索"))

func _spawn_speech_bubble(npc_id: int, text: String) -> void:
	if not actors.has(npc_id) or text.is_empty(): return
	var actor: Control = actors[npc_id]
	var bubble := PanelContainer.new()
	bubble.z_index = 40
	bubble.position = actor.position + Vector2(-65, -58)
	bubble.size = Vector2(170, 48)
	bubble.add_theme_stylebox_override("panel", _style(Color("#fffdf7f5"), 10, Color("#655c50"), 1))
	npc_layer.add_child(bubble)
	var lab := Label.new(); lab.text = text; lab.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; lab.add_theme_font_size_override("font_size", 8); lab.add_theme_color_override("font_color", colors.ink); lab.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); lab.offset_left = 7; lab.offset_right = -7; lab.offset_top = 5; lab.offset_bottom = -5; bubble.add_child(lab)
	var timer := get_tree().create_timer(2.8)
	timer.timeout.connect(func(): if is_instance_valid(bubble): bubble.queue_free())

func _refresh_all() -> void:
	_refresh_topbar()
	_refresh_rumor_card()
	_refresh_actor_states()
	_refresh_selected_hint()

func _refresh_topbar() -> void:
	top_time.text = _time_text()
	top_cash.text = "¥%d" % int(state["cash"])
	top_ap.text = str(state["ap"])

func _refresh_rumor_card() -> void:
	if not engine.has_active():
		rumor_subject.text = "暂无活跃消息"; rumor_domain.text = "等待"; rumor_text.text = "从“情报”里选一条消息。先判断值不值得碰，再决定调查还是扩散。"
		_set_metric(heat_bar, heat_value, 0); _set_metric(trace_bar, trace_value, 0); _set_metric(exposure_bar, exposure_value, 0)
		return
	var a := engine.active
	rumor_subject.text = str(a["subject"])
	rumor_domain.text = str(a["domain_label"])
	rumor_text.text = str(a["text"]) + "\n当前最深阶段：" + _deepest_stage_label()
	_set_metric(heat_bar, heat_value, float(a["heat"])); _set_metric(trace_bar, trace_value, float(a["trace"])); _set_metric(exposure_bar, exposure_value, float(a["exposure"]))

func _set_metric(bar: ProgressBar, lab: Label, value: float) -> void:
	bar.value = value; lab.text = str(roundi(value))

func _refresh_actor_states() -> void:
	for npc in npcs:
		if not actors.has(npc["id"]): continue
		var actor: NpcActor = actors[npc["id"]]
		if npc["id"] == selected_npc_id:
			actor.set_state("selected")
		elif npc.get("trace_aware", false):
			actor.set_state("trace")
		elif npc.get("heard", false):
			actor.set_state("believe" if float(npc.get("belief", 0.0)) > 0.62 else "heard")
		else:
			actor.set_state("idle")

func _refresh_selected_hint() -> void:
	if npcs.is_empty(): return
	var n: Dictionary = npcs[selected_npc_id]
	selected_hint.text = "当前人物：%s · %s · 传播欲%d / 求证%d" % [n["name"], n["job"], n["talk"], n["skeptic"]]

func _open_sheet(kind: String) -> void:
	overlay.visible = true
	for child in sheet_body.get_children(): child.queue_free()
	match kind:
		"intel": _fill_intel_sheet()
		"network": _fill_network_sheet()
		"trace": _fill_trace_sheet()
		"profile": _fill_profile_sheet()
		_: _fill_town_sheet()

func _close_sheet() -> void:
	overlay.visible = false

func _fill_intel_sheet() -> void:
	sheet_title.text = "情报市场"
	_add_help("消息不是任务按钮，而是商品。每条消息都有时效、可信度和追查风险；你不知道真相，只知道来源和当前证据。")
	for item in intel_list:
		var card := _card()
		sheet_body.add_child(card)
		var v := _card_vbox(card)
		var h := HBoxContainer.new(); v.add_child(h)
		var title := Label.new(); title.text = "%s  ·  %s" % [item["subject"], item["domain_label"]]; title.size_flags_horizontal = Control.SIZE_EXPAND_FILL; title.add_theme_font_size_override("font_size", 12); title.add_theme_color_override("font_color", colors.ink); h.add_child(title)
		var risk := Label.new(); risk.text = "追查 %d" % item["base_trace"]; risk.add_theme_font_size_override("font_size", 9); risk.add_theme_color_override("font_color", colors.danger); h.add_child(risk)
		_add_small(v, item["text"])
		_add_chips(v, ["来源："+str(item["source"]), "初始可信：%d%%" % item["confidence"], "未知真伪"])
		var b := Button.new(); b.text = "接触这条消息"; _style_button(b, true); v.add_child(b)
		var data: Dictionary = item
		b.pressed.connect(func(): _start_intel(data))

func _start_intel(item: Dictionary) -> void:
	engine.start_intel(item, state["minute"])
	for npc in npcs:
		npc["heard"] = false; npc["belief"] = 0.0; npc["node"] = ""; npc["last_spread"] = -9999; npc["rumor_depth"] = 0; npc["trace_aware"] = false
	_close_sheet(); _refresh_all()
	_show_event("线索已入手", "%s 提供了一条未经完全证实的消息。点一个人物，再选择“推给此人”。" % item["source"])

func _fill_network_sheet() -> void:
	sheet_title.text = "关系与传播节点"
	_add_help("高影响力人物传播得远，但公开程度越高，留下的痕迹越明显。熟人关系则更容易相信，也更容易形成可追溯链。")
	var sorted := npcs.duplicate()
	sorted.sort_custom(func(a,b): return int(a["influence"]) > int(b["influence"]))
	for i in mini(14, sorted.size()):
		var n: Dictionary = sorted[i]
		var card := _card(); sheet_body.add_child(card); var v := _card_vbox(card)
		var lab := Label.new(); lab.text = "%s  ·  %s" % [n["name"], n["job"]]; lab.add_theme_font_size_override("font_size", 11); lab.add_theme_color_override("font_color", colors.ink); v.add_child(lab)
		_add_small(v, "影响力 %d　传播欲 %d　求证 %d" % [n["influence"], n["talk"], n["skeptic"]])
		_add_chips(v, n["traits"] + n["social"])
		var b := Button.new(); b.text = "在地图选中此人"; _style_button(b, false); v.add_child(b)
		var id := int(n["id"]); b.pressed.connect(func(): selected_npc_id = id; _close_sheet(); _refresh_all())

func _fill_trace_sheet() -> void:
	sheet_title.text = "追查链"
	if not engine.has_active():
		_add_help("目前没有活跃消息。传播后，每一次当面转述、电话、群聊和短视频都会留下不同强度的痕迹。")
		return
	var a := engine.active
	var summary := _card(); sheet_body.add_child(summary); var sv := _card_vbox(summary)
	var title := Label.new(); title.text = "%s · %s" % [a["subject"], a["domain_label"]]; title.add_theme_font_size_override("font_size", 12); sv.add_child(title)
	_add_chips(sv, ["追查 %d" % roundi(a["trace"]), "源头暴露 %d" % roundi(a["exposure"]), "追查者 %d" % a["investigators"].size(), "传播 %d 跳" % a["spread_count"]])
	_add_small(sv, "追查不会瞬间知道是你。调查者只能从公开节点、截图、通话关系和目击者逐层回溯。越靠近第一跳的真实线索，对你越危险。")

	var clues: Array = a["clues"]
	var clue_title := Label.new(); clue_title.text = "已留下的痕迹"; clue_title.add_theme_font_size_override("font_size", 13); clue_title.add_theme_color_override("font_color", colors.ink); sheet_body.add_child(clue_title)
	if clues.is_empty(): _add_help("目前还没有明显痕迹。")
	for clue in clues.slice(maxi(0, clues.size()-12), clues.size()):
		var c := _card(); sheet_body.add_child(c); var cv := _card_vbox(c)
		var l := Label.new(); l.text = "线索·%s　强度 %.1f　距离源头 %d 跳" % [clue["type"], clue["strength"], clue["depth"]]; l.add_theme_font_size_override("font_size", 10); cv.add_child(l); _add_small(cv, clue["text"])

	var tl_title := Label.new(); tl_title.text = "传播 / 追查时间线"; tl_title.add_theme_font_size_override("font_size", 13); sheet_body.add_child(tl_title)
	var timeline: Array = a["timeline"]
	for item in timeline.slice(maxi(0, timeline.size()-18), timeline.size()):
		var l := Label.new(); l.text = "%s　%s" % [_minute_to_text(int(item["time"])), item["text"]]; l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; l.add_theme_font_size_override("font_size", 9); l.add_theme_color_override("font_color", colors.muted); sheet_body.add_child(l)

func _fill_profile_sheet() -> void:
	sheet_title.text = "人物档案"
	var n: Dictionary = npcs[selected_npc_id]
	var card := _card(); sheet_body.add_child(card); var v := _card_vbox(card)
	var title := Label.new(); title.text = "%s　%s" % [n["name"], n["job"]]; title.add_theme_font_size_override("font_size", 16); title.add_theme_color_override("font_color", colors.ink); v.add_child(title)
	_add_small(v, "%s · 影响力 %d · 传播欲 %d · 求证 %d" % [DomainData.district_names()[n["district"]], n["influence"], n["talk"], n["skeptic"]])
	_add_chips(v, n["traits"] + n["social"])
	_add_small(v, "熟人：" + "、".join(n["friends"].map(func(id): return npcs[int(id)]["name"])))
	if engine.has_active():
		var status := "尚未听说"
		if n["heard"]: status = "基本相信" if float(n["belief"]) > 0.62 else "半信半疑"
		_add_small(v, "对当前消息：%s　当前语义：%s" % [status, _active_node_label(n["node"]) if not str(n["node"]).is_empty() else "—"])
		var preview := engine.generate_speech(n, n["node"] if not str(n["node"]).is_empty() else engine.active["seed"], "react")
		var pcard := _card(); sheet_body.add_child(pcard); var pv := _card_vbox(pcard); var pt := Label.new(); pt.text = "他/她可能会怎么说"; pt.add_theme_font_size_override("font_size", 11); pv.add_child(pt); _add_small(pv, "“%s”" % preview)

func _fill_town_sheet() -> void:
	sheet_title.text = "小镇动态"
	_add_help("地图才是主界面。这里以后会放自然发生的城市事件，而不是任务清单。")

func _deepest_stage_label() -> String:
	if not engine.has_active(): return "—"
	var deepest := str(engine.active["seed"]); var stage := 1
	for n in npcs:
		if n["heard"] and not str(n["node"]).is_empty():
			var s := engine.node_stage(n["node"])
			if s > stage: stage = s; deepest = n["node"]
	return "%d级 · %s" % [stage, _active_node_label(deepest)]

func _active_node_label(node_key: String) -> String:
	if not engine.has_active() or node_key.is_empty(): return "—"
	var d: Dictionary = DomainData.domains().get(engine.active["domain"], {})
	return str(d.get("nodes", {}).get(node_key, {}).get("label", node_key))

func _show_event(title: String, text: String) -> void:
	event_title.text = title; event_text.text = text; event_panel.visible = true; event_hide_timer.start()

func _time_text() -> String:
	return "第%d天 %s" % [state["day"], _minute_to_text(state["minute"])]

func _minute_to_text(minute: int) -> String:
	return "%02d:%02d" % [int(minute / 60) % 24, minute % 60]

func _sample_strings(source: Array[String], count: int) -> Array[String]:
	var copy := source.duplicate(); copy.shuffle(); var out: Array[String] = []
	for i in mini(count, copy.size()): out.append(copy[i])
	return out

func _style(bg: Color, radius: int, border: Color, border_width: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new(); s.bg_color = bg
	s.corner_radius_top_left = radius; s.corner_radius_top_right = radius; s.corner_radius_bottom_left = radius; s.corner_radius_bottom_right = radius
	if border_width > 0:
		s.border_color = border; s.border_width_left = border_width; s.border_width_top = border_width; s.border_width_right = border_width; s.border_width_bottom = border_width
	return s

func _card() -> PanelContainer:
	var p := PanelContainer.new(); p.add_theme_stylebox_override("panel", _style(Color("#fffaf1"), 12, colors.line, 1)); return p

func _card_vbox(card: PanelContainer) -> VBoxContainer:
	var m := MarginContainer.new(); m.add_theme_constant_override("margin_left", 9); m.add_theme_constant_override("margin_right", 9); m.add_theme_constant_override("margin_top", 8); m.add_theme_constant_override("margin_bottom", 8); card.add_child(m)
	var v := VBoxContainer.new(); v.add_theme_constant_override("separation", 5); m.add_child(v); return v

func _add_help(text: String) -> void:
	var p := _card(); sheet_body.add_child(p); var v := _card_vbox(p); _add_small(v, text)

func _add_small(parent: Control, text: String) -> void:
	var l := Label.new(); l.text = text; l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART; l.add_theme_font_size_override("font_size", 10); l.add_theme_color_override("font_color", colors.muted); parent.add_child(l)

func _add_chips(parent: Control, values: Array) -> void:
	var flow := HFlowContainer.new(); flow.add_theme_constant_override("h_separation", 4); flow.add_theme_constant_override("v_separation", 4); parent.add_child(flow)
	for value in values:
		var l := Label.new(); l.text = str(value); l.add_theme_font_size_override("font_size", 8); l.add_theme_color_override("font_color", colors.ink); l.add_theme_stylebox_override("normal", _style(Color("#e6dac7"), 7, Color.TRANSPARENT, 0)); flow.add_child(l)

func _style_button(b: Button, primary: bool) -> void:
	b.focus_mode = Control.FOCUS_NONE; b.add_theme_font_size_override("font_size", 10); b.add_theme_color_override("font_color", colors.ink)
	var bg := Color("#f7ead4") if primary else Color("#fffaf0"); var border := Color("#b88a52") if primary else colors.line
	b.add_theme_stylebox_override("normal", _style(bg, 9, border, 1)); b.add_theme_stylebox_override("pressed", _style(bg.darkened(0.05), 9, border, 1))
