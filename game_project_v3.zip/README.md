# 《这消息谁传的？》Godot 原生移动版 v0.1.0

这是从 HTML 玩法原型迁移出来的 **Godot 4.7.2 原生 2D 工程**，目标平台首先是 Android 竖屏手机。

## 当前可玩内容

- 96 个地图 NPC，可点击、会移动。
- 手机竖屏地图主界面 + 底部导航/抽屉 UI。
- 情报市场：来源、可信度、追查风险。
- 慢传播：玩家推动后有冷却；NPC 需要等到自己的社交窗口才会继续传播。
- 领域隔离语义树：银行、企业、地产、教育、餐饮、市场不会互相乱串。
- 不同职业拥有不同说话方式，并带话术去重记忆。
- 传播媒介：当面、电话、群聊、短视频。
- 追查链：目击、通话关系、群聊截图、公开视频；调查者沿传播链逐层回溯。
- 玩家可主动推动、降温、查看追查、制造假线索。

## 运行

工程入口：`scenes/Main.tscn`

推荐 Godot：**4.7.2 stable**。

## Android 自动构建

仓库包含 `.github/workflows/android.yml`。

每次推送到 `main`，或在 GitHub 的 **Actions → Build Android APK → Run workflow** 手动运行后，会：

1. 配置 Java 17 与 Android SDK；
2. 下载 Godot 4.7.2 与匹配的 export templates；
3. 导入工程并检查脚本；
4. 导出 arm64 Debug APK；
5. 上传名为 **这消息谁传的-v0.1.0-Android** 的构建产物。

下载产物中的 `whosaidit-v0.1.0-debug.apk` 即可在 Android 手机上安装测试。

> 第一次构建需要下载 Godot export templates，时间会明显长于之后的缓存构建。

## 项目结构

- `scripts/main.gd`：地图、UI、时间推进与玩家操作
- `scripts/rumor_engine.gd`：传播、语义变化、媒介痕迹、追查核心
- `scripts/domain_data.gd`：领域话语树、职业、地点、情报数据
- `scripts/npc_actor.gd`：NPC 地图节点与移动/点击反馈
- `export_presets.cfg`：Android arm64 调试导出配置
- `.github/workflows/android.yml`：APK 自动构建

## 当前版本定位

v0.1.0 是第一版 Godot 可玩骨架，重点是验证：**地图操作是否舒服、传播是否足够慢、追查是否有压力、NPC 说话是否自然。**
后续内容会继续在 Godot 工程上扩展，而不是回到网页版本。


## v0.1.2 build fix
- Fixed Godot 4.7.2 GDScript type inference for rumor carrier index.
- ETC2/ASTC Android compression remains enabled.
