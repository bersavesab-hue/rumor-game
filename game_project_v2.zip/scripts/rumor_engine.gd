class_name RumorEngine
extends RefCounted

var rng := RandomNumberGenerator.new()
var domains: Dictionary = {}
var role_speech: Dictionary = {}
var active: Dictionary = {}
var speech_memory: Dictionary = {}

func _init() -> void:
	rng.randomize()
	domains = DomainData.domains()
	role_speech = DomainData.role_speech()

func has_active() -> bool:
	return not active.is_empty()

func start_intel(intel: Dictionary, minute: int) -> void:
	active = intel.duplicate(true)
	active["heat"] = 6.0
	active["trace"] = float(intel.get("base_trace", 5))
	active["exposure"] = 6.0
	active["started_at"] = minute
	active["timeline"] = []
	active["carriers"] = []
	active["clues"] = []
	active["investigators"] = []
	active["trace_progress"] = 0.0
	active["max_stage"] = 1
	active["spread_count"] = 0
	active["last_auto"] = minute
	active["last_trace"] = minute
	active["player_cooldown_until"] = minute
	speech_memory.clear()

func stop_active() -> void:
	active.clear()
	speech_memory.clear()

func role_relevance(npc: Dictionary) -> float:
	if active.is_empty():
		return 0.0
	var domain: Dictionary = domains.get(active["domain"], {})
	var result := 0.0
	if domain.get("roles", []).has(npc.get("job", "")):
		result += 0.27
	if domain.get("districts", []).has(npc.get("district", "")):
		result += 0.13
	return result

func manual_spread(npcs: Array, target_id: int, minute: int) -> Dictionary:
	if active.is_empty():
		return {"ok": false, "reason":"没有活跃消息"}
	if minute < int(active.get("player_cooldown_until", minute)):
		return {"ok": false, "reason":"消息还在发酵，稍等再推"}
	if target_id < 0 or target_id >= npcs.size():
		return {"ok": false, "reason":"没有合适的目标"}
	var target: Dictionary = npcs[target_id]
	if target.get("heard", false):
		return {"ok": false, "reason":"这个人已经听说过了"}
	var belief := clampf(0.48 + (100.0 - float(target.get("skeptic", 50))) / 220.0 + role_relevance(target) * 0.35, 0.18, 0.92)
	target["heard"] = true
	target["belief"] = belief
	target["node"] = active["seed"]
	target["last_spread"] = minute
	target["rumor_depth"] = 0
	var wording := generate_speech(target, active["seed"], "share")
	var carrier := {
		"from": -1, "to": target_id, "time": minute,
		"medium":"当面", "wording":wording, "trace":4.0, "depth":0
	}
	active["carriers"].append(carrier)
	active["clues"].append({"type":"目击","strength":4.0,"depth":0,"carrier":active["carriers"].size()-1,"text":"第一位听众记得消息来自一次当面交流。"})
	active["timeline"].append({"time":minute,"text":"你把消息告诉了 %s（%s）" % [target["name"], target["job"]]})
	active["heat"] = clampf(float(active["heat"]) + 8.0, 0.0, 100.0)
	active["trace"] = clampf(float(active["trace"]) + 2.5, 0.0, 100.0)
	active["exposure"] = clampf(float(active["exposure"]) + 2.0, 0.0, 100.0)
	active["spread_count"] = int(active["spread_count"]) + 1
	active["player_cooldown_until"] = minute + 24
	return {"ok":true,"target":target_id,"wording":wording,"medium":"当面","node":active["seed"]}

func auto_spread_step(npcs: Array, minute: int) -> Dictionary:
	if active.is_empty():
		return {}
	if minute - int(active.get("last_auto", minute)) < 12:
		return {}
	active["last_auto"] = minute
	var speakers: Array = []
	for npc in npcs:
		if not npc.get("heard", false):
			continue
		if float(npc.get("belief", 0.0)) < 0.20:
			continue
		var wait_required := int(npc.get("spread_wait", 34))
		if minute - int(npc.get("last_spread", -9999)) < wait_required:
			continue
		var chance := float(npc.get("talk", 50)) / 100.0 * 0.23 + float(active.get("heat", 0.0)) / 700.0 + role_relevance(npc) * 0.10
		if npc.get("social", []).has("大嘴巴") or npc.get("social", []).has("爱发群聊"):
			chance += 0.08
		if npc.get("social", []).has("嘴严"):
			chance -= 0.10
		if rng.randf() < clampf(chance, 0.02, 0.52):
			speakers.append(npc)
	if speakers.is_empty():
		return {}
	var speaker: Dictionary = speakers[rng.randi_range(0, speakers.size()-1)]
	var candidates: Array = []
	for npc in npcs:
		if npc["id"] == speaker["id"] or npc.get("heard", false):
			continue
		candidates.append(npc)
	if candidates.is_empty():
		return {}
	candidates.sort_custom(func(a, b): return _target_score(speaker, a) > _target_score(speaker, b))
	var target: Dictionary = candidates[0]
	var medium := choose_medium(speaker)
	var belief := clampf(float(speaker.get("belief", 0.55)) * 0.68 + (100.0 - float(target.get("skeptic", 50))) / 360.0 + role_relevance(target) * 0.22 + rng.randf_range(-0.08, 0.08), 0.08, 0.95)
	target["heard"] = true
	target["belief"] = belief
	var current_node: String = str(speaker.get("node", active["seed"]))
	var next_node: String = next_node_for(target, current_node)
	target["node"] = next_node
	target["last_spread"] = minute
	target["spread_wait"] = rng.randi_range(28, 68)
	var depth := int(speaker.get("rumor_depth", 0)) + 1
	target["rumor_depth"] = depth
	speaker["last_spread"] = minute
	var wording := generate_speech(target, next_node, "share")
	var trace_strength := medium_trace(medium)
	var carrier := {
		"from":speaker["id"], "to":target["id"], "time":minute,
		"medium":medium, "wording":wording, "trace":trace_strength, "depth":depth
	}
	active["carriers"].append(carrier)
	var carrier_index := active["carriers"].size()-1
	if trace_strength >= 5.0:
		active["clues"].append({
			"type":clue_type(medium), "strength":trace_strength, "depth":depth,
			"carrier":carrier_index, "text":clue_text(speaker, target, medium)
		})
	active["timeline"].append({"time":minute,"text":"%s 通过%s把消息传给 %s" % [speaker["name"], medium, target["name"]]})
	var changed := next_node != current_node
	active["heat"] = clampf(float(active["heat"]) + (4.5 if changed else 2.6), 0.0, 100.0)
	active["trace"] = clampf(float(active["trace"]) + trace_strength * 0.22, 0.0, 100.0)
	active["spread_count"] = int(active["spread_count"]) + 1
	active["max_stage"] = maxi(int(active["max_stage"]), node_stage(next_node))
	return {"speaker":speaker["id"],"target":target["id"],"medium":medium,"wording":wording,"node":next_node,"changed":changed}

func trace_step(npcs: Array, minute: int) -> Dictionary:
	if active.is_empty():
		return {}
	if float(active.get("heat", 0.0)) < 20.0:
		return {}
	if minute - int(active.get("last_trace", minute)) < 18:
		return {}
	active["last_trace"] = minute
	var result: Dictionary = {}
	if active["investigators"].is_empty() and rng.randf() < 0.30 + float(active["heat"]) / 250.0:
		var possible: Array = []
		for npc in npcs:
			if npc.get("job", "") in ["本地记者","银行柜员","客户经理","企业财务","物业人员","小学老师"]:
				possible.append(npc)
		if not possible.is_empty():
			possible.sort_custom(func(a, b): return role_relevance(a) > role_relevance(b))
			var inv: Dictionary = possible[0]
			active["investigators"].append(inv["id"])
			inv["trace_aware"] = true
			active["trace"] = clampf(float(active["trace"]) + 5.0, 0.0, 100.0)
			active["timeline"].append({"time":minute,"text":"%s（%s）开始追查来源" % [inv["name"], inv["job"]]})
			result = {"kind":"investigator","npc":inv["id"],"text":"%s 开始追查来源" % inv["name"]}
	if not active["investigators"].is_empty() and not active["clues"].is_empty() and rng.randf() < 0.42:
		var clues: Array = active["clues"]
		clues.sort_custom(func(a, b): return _clue_priority(a) > _clue_priority(b))
		var clue: Dictionary = clues[0]
		var strength := float(clue.get("strength", 0.0))
		active["trace"] = clampf(float(active["trace"]) + maxf(0.0, strength * 0.48), 0.0, 100.0)
		var depth := int(clue.get("depth", 99))
		var exposure_gain := strength * clampf(1.0 - float(depth) * 0.15, 0.12, 1.0) * 0.42
		if strength < 0.0:
			exposure_gain = strength * 0.7
		active["exposure"] = clampf(float(active["exposure"]) + exposure_gain, 0.0, 100.0)
		active["trace_progress"] = clampf(float(active["trace_progress"]) + maxf(0.0, strength) * 0.65, 0.0, 100.0)
		active["timeline"].append({"time":minute,"text":"追查者利用【%s】向源头推进" % clue["type"]})
		result = {"kind":"clue","clue":clue,"text":"追查者利用【%s】向源头推进" % clue["type"]}
		# 已使用的真实线索会弱化，避免每次重复吃同一条。
		clue["strength"] = strength * 0.62
	return result

func cool_down() -> void:
	if active.is_empty():
		return
	active["heat"] = maxf(0.0, float(active["heat"]) - 13.0)
	active["trace"] = maxf(0.0, float(active["trace"]) - 2.0)
	active["player_cooldown_until"] = int(active.get("player_cooldown_until", 0)) + 18

func plant_decoy() -> void:
	if active.is_empty():
		return
	active["exposure"] = maxf(0.0, float(active["exposure"]) - 13.0)
	active["trace"] = minf(100.0, float(active["trace"]) + 4.0)
	active["clues"].append({"type":"假线索","strength":-7.0,"depth":0,"carrier":-1,"text":"一条人为制造的错误来源开始干扰追查。"})
	active["timeline"].append({"time":0,"text":"你投放了一条假线索"})

func passive_decay() -> void:
	if active.is_empty():
		return
	active["heat"] = maxf(0.0, float(active["heat"]) - 0.11)

func choose_medium(npc: Dictionary) -> String:
	var socials: Array = npc.get("social", [])
	var choices := ["当面","电话"]
	if socials.has("爱发群聊"):
		choices.append_array(["群聊","群聊"])
	if socials.has("爱直播"):
		choices.append("短视频")
	if socials.has("只跟熟人说"):
		choices.append("当面")
	return choices[rng.randi_range(0, choices.size()-1)]

func medium_trace(medium: String) -> float:
	match medium:
		"短视频": return 11.0
		"群聊": return 8.0
		"电话": return 5.0
		_: return 3.0

func clue_type(medium: String) -> String:
	match medium:
		"短视频": return "公开视频"
		"群聊": return "群聊截图"
		"电话": return "通话关系"
		_: return "目击"

func clue_text(speaker: Dictionary, target: Dictionary, medium: String) -> String:
	match medium:
		"短视频": return "%s 的公开视频留下了时间戳。" % speaker["name"]
		"群聊": return "群聊截图保留了 %s 的转发痕迹。" % speaker["name"]
		"电话": return "%s 与 %s 的通话时间和传播时间接近。" % [speaker["name"], target["name"]]
		_: return "%s 记得是 %s 当面告诉自己的。" % [target["name"], speaker["name"]]

func next_node_for(npc: Dictionary, current: String) -> String:
	var domain: Dictionary = domains.get(active["domain"], {})
	var node: Dictionary = domain.get("nodes", {}).get(current, {})
	var children: Array = node.get("children", [])
	if children.is_empty():
		return current
	var chance := 0.15
	if npc.get("social", []).has("喜欢添油加醋"):
		chance += 0.15
	if npc.get("traits", []).has("多疑"):
		chance += 0.05
	if rng.randf() > chance:
		return current
	return str(children[rng.randi_range(0, children.size()-1)])

func generate_speech(npc: Dictionary, node_key: String, mode: String = "share") -> String:
	if active.is_empty():
		return ""
	var domain: Dictionary = domains.get(active["domain"], {})
	var node: Dictionary = domain.get("nodes", {}).get(node_key, {})
	var lines: Array = node.get("lines", [active.get("text", "有人在议论")])
	var style: Dictionary = role_speech.get(npc.get("job", ""), role_speech["default"])
	var prefix := _fresh_pick(npc, "prefix", style.get("prefix", []))
	var core := _fresh_pick(npc, "node_%s" % node_key, lines)
	var suffix := _fresh_pick(npc, "suffix", style.get("suffix", []))
	var belief := float(npc.get("belief", 0.5))
	var reaction := "先看看后面还有没有新消息"
	if belief > 0.66:
		reaction = _fresh_pick(npc, "believe", ["这事八成有点东西","我先做点准备","不像完全空穴来风","这么多人说我得留意"])
	elif belief < 0.34:
		reaction = _fresh_pick(npc, "doubt", ["没有证据我不太信","这说法有点夸张","我先不跟风","前后还对不上"])
	else:
		reaction = _fresh_pick(npc, "neutral", ["我先记着","现在信息太少","还得再观察","我不下结论"])
	if mode == "react":
		return "%s。%s。" % [core, reaction]
	return "%s，%s。%s" % [prefix, core, suffix]

func node_stage(node_key: String) -> int:
	if active.is_empty():
		return 1
	return int(domains.get(active["domain"], {}).get("nodes", {}).get(node_key, {}).get("stage", 1))

func _fresh_pick(npc: Dictionary, key: String, options: Array) -> String:
	if options.is_empty():
		return ""
	var npc_id := int(npc.get("id", -1))
	var mem_key := "%s:%s" % [npc_id, key]
	if not speech_memory.has(mem_key):
		speech_memory[mem_key] = []
	var used: Array = speech_memory[mem_key]
	var pool: Array = []
	for item in options:
		if not used.has(item):
			pool.append(item)
	if pool.is_empty():
		used.clear()
		pool = options.duplicate()
	var picked: String = str(pool[rng.randi_range(0, pool.size()-1)])
	used.append(picked)
	if used.size() > mini(6, options.size()):
		used.pop_front()
	return picked

func _target_score(speaker: Dictionary, target: Dictionary) -> float:
	var score := role_relevance(target) * 2.0
	if speaker.get("friends", []).has(target.get("id", -1)):
		score += 0.8
	if speaker.get("district", "") == target.get("district", ""):
		score += 0.3
	score += rng.randf_range(0.0, 0.4)
	return score

func _clue_priority(clue: Dictionary) -> float:
	var strength := float(clue.get("strength", 0.0))
	var depth := int(clue.get("depth", 99))
	if strength < 0.0:
		return 999.0
	return strength + maxf(0.0, 8.0 - float(depth))
