extends Control

class ArtifactView extends Control:
    var shape: String = "vase"

    func _ready() -> void:
        custom_minimum_size = Vector2(0, 180)
        mouse_filter = Control.MOUSE_FILTER_IGNORE

    func set_shape(value: String) -> void:
        shape = value
        queue_redraw()

    func _draw() -> void:
        var center := Vector2(size.x * 0.5, size.y * 0.5)
        if shape == "vase":
            var body := PackedVector2Array([
                center + Vector2(-42, -35), center + Vector2(-50, 0),
                center + Vector2(-35, 55), center + Vector2(0, 72),
                center + Vector2(35, 55), center + Vector2(50, 0),
                center + Vector2(42, -35), center + Vector2(20, -52),
                center + Vector2(18, -72), center + Vector2(-18, -72),
                center + Vector2(-20, -52)
            ])
            draw_colored_polygon(body, Color("b9d0c7"))
            draw_polyline(body, Color("667a72"), 3.0, true)
            draw_line(center + Vector2(-18, -72), center + Vector2(18, -72), Color("667a72"), 3.0)
            draw_arc(center + Vector2(0, 7), 31, 0, TAU, 28, Color("6f8d9a"), 3.0)
            draw_arc(center + Vector2(0, 18), 21, 0, TAU, 24, Color("6f8d9a"), 2.0)
        elif shape == "jade":
            draw_circle(center, 61, Color("789d7b"))
            draw_circle(center, 32, Color("ece5d9"))
            draw_arc(center, 61, 0, TAU, 64, Color("486851"), 4.0)
            draw_arc(center + Vector2(-11, -9), 18, 0.4, 4.7, 24, Color("bad0b8"), 5.0)
        elif shape == "bronze":
            draw_rect(Rect2(center + Vector2(-53, -32), Vector2(106, 78)), Color("40594b"), true)
            draw_arc(center + Vector2(-58, -7), 21, -1.3, 1.3, 20, Color("31463b"), 6.0)
            draw_arc(center + Vector2(58, -7), 21, 1.84, 4.44, 20, Color("31463b"), 6.0)
            draw_line(center + Vector2(-34, -5), center + Vector2(34, -5), Color("7f9a87"), 4.0)
            draw_line(center + Vector2(-26, 11), center + Vector2(26, 11), Color("7f9a87"), 4.0)
        elif shape == "scroll":
            draw_rect(Rect2(center + Vector2(-66, -49), Vector2(132, 98)), Color("e7dcc4"), true)
            draw_rect(Rect2(center + Vector2(-52, -38), Vector2(104, 76)), Color("f3ead8"), true)
            draw_line(center + Vector2(-18, -15), center + Vector2(21, -30), Color("585148"), 3.0)
            draw_line(center + Vector2(-18, 1), center + Vector2(28, -10), Color("585148"), 3.0)
            draw_line(center + Vector2(-18, 18), center + Vector2(15, 11), Color("585148"), 3.0)
        else:
            draw_circle(center, 54, Color("9c7638"))
            draw_circle(center, 25, Color("d8c49d"))
            draw_rect(Rect2(center + Vector2(-17, -17), Vector2(34, 34)), Color("27231d"), true)
            draw_arc(center, 54, 0, TAU, 64, Color("604622"), 5.0)

const PAPER := Color("f3efe7")
const CARD := Color("fbf8f2")
const INK := Color("1c1a16")
const MUTED := Color("746d64")
const LINE := Color("d6ccbc")
const RED := Color("8e2f26")
const GOLD := Color("9b7a42")
const DARK := Color("242119")
const GOOD := Color("315f43")
const BAD := Color("873a31")

var state: Dictionary = {
    "day": 1,
    "cash": 2800,
    "rep": 0,
    "eye": 1,
    "visitor": 1,
    "max_visitor": 5,
    "inventory": [],
    "market": {"瓷器": 1.0, "玉器": 1.0, "青铜": 1.0, "书画": 1.0, "钱币": 1.0},
    "current": {},
    "inspect_count": 0
}

var item_defs: Array = [
    {"name":"青花缠枝莲瓶","cat":"瓷器","shape":"vase","true_min":1800,"true_max":4200,"fake_min":80,"fake_max":260},
    {"name":"豆青釉小罐","cat":"瓷器","shape":"vase","true_min":900,"true_max":2600,"fake_min":60,"fake_max":180},
    {"name":"白玉螭龙佩","cat":"玉器","shape":"jade","true_min":2400,"true_max":6200,"fake_min":120,"fake_max":480},
    {"name":"沁色谷纹玉璧","cat":"玉器","shape":"jade","true_min":1600,"true_max":4800,"fake_min":90,"fake_max":350},
    {"name":"兽面纹铜簋","cat":"青铜","shape":"bronze","true_min":4200,"true_max":9800,"fake_min":220,"fake_max":800},
    {"name":"设色山水小轴","cat":"书画","shape":"scroll","true_min":1500,"true_max":5200,"fake_min":50,"fake_max":260},
    {"name":"行书诗札","cat":"书画","shape":"scroll","true_min":1000,"true_max":3800,"fake_min":40,"fake_max":180},
    {"name":"咸丰重宝宝泉局","cat":"钱币","shape":"coin","true_min":700,"true_max":2200,"fake_min":35,"fake_max":120}
]

var people: Array = [
    {"name":"周伯年","initial":"周","desc":"附近居民 · 神色有些焦急","trait":"急售","patience":2,"flex":0.78,"quote":"家里急着用钱，这件东西老人留下的。"},
    {"name":"马三成","initial":"马","desc":"跑货商 · 说话很快","trait":"老江湖","patience":3,"flex":0.90,"quote":"东西你自己看，别问来路，价合适就成交。"},
    {"name":"沈月兰","initial":"沈","desc":"退休教师 · 态度谨慎","trait":"惜售","patience":2,"flex":0.94,"quote":"这是家里收了很多年的，我只是先问问价。"},
    {"name":"何志远","initial":"何","desc":"工地包工头 · 手头缺现钱","trait":"急用钱","patience":2,"flex":0.72,"quote":"今天就想变现，别绕弯子，您直接开价。"}
]

var clue_names := {
    "surface":"釉色/材质", "mark":"底款", "body":"胎骨",
    "wear":"磨损", "sound":"敲声", "weight":"重量"
}

var clue_bank := {
    "surface": {
        "t":["表面老化过渡自然，细部光泽不一","材质内部结构自然，没有统一做旧感","锈蚀与包浆层次交错，附着牢固"],
        "f":["表面光泽刺眼，做旧色像浮在最外层","酸蚀坑过于均匀，像批量处理","锈层单薄，细缝里反而很干净"]
    },
    "mark": {
        "t":["款识笔锋有停顿，字口老化与器身一致","刀工转折不机械，槽内积垢连续","印色和纸张老化程度基本同步"],
        "f":["款识过分标准，像照图录描出来的","字口边缘锐利，槽内几乎没有老化","印章位置刻意，印泥颜色明显偏新"]
    },
    "body": {
        "t":["胎质颗粒细密，露胎处老化自然","内里结构与旧工痕互相吻合","纸纤维断面自然，没有现代漂白感"],
        "f":["露胎过白，颗粒与老器常见特征不符","孔道出现高速电动工具的规则纹路","纸张纤维过整齐，疑似现代机制纸"]
    },
    "wear": {
        "t":["口沿磨损有轻重差，符合长期使用习惯","高点磨平、低处积垢，逻辑连贯","卷轴开合处损耗比静止位置更明显"],
        "f":["磨损集中在最显眼位置，像故意做给人看","所谓老伤颜色比周围新","所有凸起的磨损程度几乎一样"]
    },
    "sound": {
        "t":["敲击声清脆但不尖，余音自然","音色厚实，不发飘","金属声沉稳，与器壁厚度吻合"],
        "f":["声音发脆发尖，像新烧器","回声短促，结构显得发空","金属声过亮，像新铸后再做旧"]
    },
    "weight": {
        "t":["手感压手，重心与器型匹配","重量落在同类老器常见区间","局部厚薄变化符合手工制作"],
        "f":["明显偏轻，器壁与外观不相称","重量过于标准，像模具批量品","底部疑似人为加重，重心异常"]
    }
}

var current_view := "desk"
var root_box: VBoxContainer
var desk_view: VBoxContainer
var stock_view: VBoxContainer
var market_view: VBoxContainer
var people_view: VBoxContainer
var stats_labels: Dictionary = {}
var event_label: Label
var visitor_label: Label
var avatar_label: Label
var customer_name: Label
var customer_desc: Label
var quote_label: Label
var artifact_view: ArtifactView
var item_name: Label
var item_sub: Label
var energy_label: Label
var checks_grid: GridContainer
var clues_box: VBoxContainer
var ask_label: Label
var talk_label: Label
var offer_input: LineEdit
var buy_button: Button
var notice_label: Label
var inventory_box: VBoxContainer
var market_grid: GridContainer
var result_dialog: AcceptDialog

func _ready() -> void:
    randomize()
    load_game()
    if state.get("current", {}).is_empty():
        state["current"] = make_item()
    build_ui()
    random_market(false)
    render_all()

func panel_style(bg: Color = CARD, radius: int = 16, border: Color = LINE) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = bg
    s.border_color = border
    s.set_border_width_all(1)
    s.set_corner_radius_all(radius)
    s.content_margin_left = 12
    s.content_margin_right = 12
    s.content_margin_top = 10
    s.content_margin_bottom = 10
    return s

func add_text(parent: Node, text: String, size: int = 14, color: Color = INK) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    parent.add_child(l)
    return l

func make_button(text: String, accent: bool = false) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(0, 42)
    b.add_theme_font_size_override("font_size", 13)
    b.add_theme_color_override("font_color", Color.WHITE if accent else INK)
    b.add_theme_stylebox_override("normal", panel_style(RED if accent else Color("fffdf8"), 12, RED if accent else LINE))
    b.add_theme_stylebox_override("pressed", panel_style(Color("6f251f") if accent else Color("e9e0d2"), 12, RED if accent else LINE))
    b.add_theme_stylebox_override("hover", b.get_theme_stylebox("normal"))
    return b

func build_ui() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var bg := ColorRect.new()
    bg.color = PAPER
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(bg)

    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    margin.add_theme_constant_override("margin_left", 12)
    margin.add_theme_constant_override("margin_right", 12)
    margin.add_theme_constant_override("margin_top", 10)
    margin.add_theme_constant_override("margin_bottom", 8)
    add_child(margin)

    root_box = VBoxContainer.new()
    root_box.add_theme_constant_override("separation", 10)
    margin.add_child(root_box)

    build_header()

    var body_scroll := ScrollContainer.new()
    body_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    body_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
    root_box.add_child(body_scroll)

    var views := Control.new()
    views.custom_minimum_size = Vector2(0, 630)
    views.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    body_scroll.add_child(views)

    desk_view = VBoxContainer.new()
    desk_view.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    desk_view.add_theme_constant_override("separation", 10)
    views.add_child(desk_view)
    build_desk(desk_view)

    stock_view = VBoxContainer.new()
    stock_view.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    stock_view.visible = false
    views.add_child(stock_view)
    build_stock(stock_view)

    market_view = VBoxContainer.new()
    market_view.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    market_view.visible = false
    views.add_child(market_view)
    build_market(market_view)

    people_view = VBoxContainer.new()
    people_view.set_anchors_and_offsets_preset(Control.PRESET_TOP_WIDE)
    people_view.visible = false
    views.add_child(people_view)
    build_people(people_view)

    build_tabs()

    result_dialog = AcceptDialog.new()
    result_dialog.title = "结果"
    add_child(result_dialog)

func build_header() -> void:
    var head := VBoxContainer.new()
    head.add_theme_constant_override("separation", 8)
    root_box.add_child(head)

    var title_row := HBoxContainer.new()
    head.add_child(title_row)
    var title := add_text(title_row, "当铺鉴宝", 24, INK)
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    var seal := add_text(title_row, "眼力", 12, RED)
    seal.add_theme_stylebox_override("normal", panel_style(Color("fff7ef"), 2, RED))

    var stats := HBoxContainer.new()
    stats.add_theme_constant_override("separation", 6)
    head.add_child(stats)
    for entry in [["day","营业日"],["cash","现金"],["rep","口碑"],["eye","眼力"]]:
        var box := VBoxContainer.new()
        box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        box.add_theme_stylebox_override("panel", panel_style(Color("fbf8f2"), 10, LINE))
        var p := PanelContainer.new()
        p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        p.add_theme_stylebox_override("panel", panel_style(Color("fbf8f2"), 10, LINE))
        stats.add_child(p)
        p.add_child(box)
        var big := add_text(box, "-", 14, INK)
        stats_labels[entry[0]] = big
        add_text(box, entry[1], 10, MUTED)

    var event_panel := PanelContainer.new()
    event_panel.add_theme_stylebox_override("panel", panel_style(Color("fff7e9"), 12, Color("cdbb95")))
    head.add_child(event_panel)
    event_label = add_text(event_panel, "今日行情平稳。", 11, Color("675538"))

func build_desk(parent: VBoxContainer) -> void:
    var card := PanelContainer.new()
    card.add_theme_stylebox_override("panel", panel_style(CARD, 17, LINE))
    parent.add_child(card)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 10)
    card.add_child(box)

    var customer_row := HBoxContainer.new()
    box.add_child(customer_row)
    avatar_label = add_text(customer_row, "周", 20, Color.WHITE)
    avatar_label.custom_minimum_size = Vector2(46, 46)
    avatar_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    avatar_label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    avatar_label.add_theme_stylebox_override("normal", panel_style(Color("9d896b"), 12, Color("9d896b")))
    var customer_text := VBoxContainer.new()
    customer_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    customer_row.add_child(customer_text)
    customer_name = add_text(customer_text, "周伯年", 15, INK)
    customer_desc = add_text(customer_text, "附近居民", 11, MUTED)
    visitor_label = add_text(customer_row, "第 1/5 位", 11, MUTED)

    var quote_panel := PanelContainer.new()
    quote_panel.add_theme_stylebox_override("panel", panel_style(Color("eee6d9"), 10, Color("eee6d9")))
    box.add_child(quote_panel)
    quote_label = add_text(quote_panel, "“掌柜的，您给掌掌眼。”", 14, INK)

    var stage := PanelContainer.new()
    stage.custom_minimum_size = Vector2(0, 245)
    stage.add_theme_stylebox_override("panel", panel_style(Color("ece4d7"), 14, Color("d1c4b1")))
    box.add_child(stage)
    var stage_box := VBoxContainer.new()
    stage_box.alignment = BoxContainer.ALIGNMENT_CENTER
    stage.add_child(stage_box)
    artifact_view = ArtifactView.new()
    stage_box.add_child(artifact_view)
    item_name = add_text(stage_box, "青花缠枝莲瓶", 18, INK)
    item_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    item_sub = add_text(stage_box, "瓷器 · 来历未明 · 未鉴定", 11, MUTED)
    item_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER

    var check_head := HBoxContainer.new()
    box.add_child(check_head)
    var check_title := add_text(check_head, "挑线索，不可能全看", 13, INK)
    check_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    energy_label = add_text(check_head, "鉴定精力 3/3", 11, RED)

    checks_grid = GridContainer.new()
    checks_grid.columns = 3
    checks_grid.add_theme_constant_override("h_separation", 6)
    checks_grid.add_theme_constant_override("v_separation", 6)
    box.add_child(checks_grid)

    clues_box = VBoxContainer.new()
    clues_box.add_theme_constant_override("separation", 5)
    box.add_child(clues_box)

    var sep := HSeparator.new()
    sep.add_theme_color_override("separation", LINE)
    box.add_child(sep)

    var price_head := HBoxContainer.new()
    box.add_child(price_head)
    ask_label = add_text(price_head, "卖家开价：¥0", 12, MUTED)
    ask_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    talk_label = add_text(price_head, "暂未议价", 11, MUTED)

    var offer_row := HBoxContainer.new()
    offer_row.add_theme_constant_override("separation", 8)
    box.add_child(offer_row)
    offer_input = LineEdit.new()
    offer_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    offer_input.keyboard_type = LineEdit.KEYBOARD_TYPE_NUMBER
    offer_input.add_theme_font_size_override("font_size", 16)
    offer_input.add_theme_stylebox_override("normal", panel_style(Color.WHITE, 11, LINE))
    offer_row.add_child(offer_input)
    var offer_btn := make_button("报价", false)
    offer_btn.custom_minimum_size = Vector2(82, 42)
    offer_btn.pressed.connect(_offer)
    offer_row.add_child(offer_btn)

    var quick := HBoxContainer.new()
    quick.add_theme_constant_override("separation", 5)
    box.add_child(quick)
    for entry in [["狠压45%",0.45],["试探60%",0.60],["稳妥75%",0.75],["接近开价",0.90]]:
        var qb := make_button(entry[0], false)
        qb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        qb.custom_minimum_size.y = 35
        qb.add_theme_font_size_override("font_size", 10)
        qb.pressed.connect(_quick_offer.bind(entry[1]))
        quick.add_child(qb)

    var deal_row := HBoxContainer.new()
    deal_row.add_theme_constant_override("separation", 8)
    box.add_child(deal_row)
    buy_button = make_button("按谈成价收下", true)
    buy_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    buy_button.disabled = true
    buy_button.pressed.connect(_buy)
    deal_row.add_child(buy_button)
    var reject_btn := make_button("不收，送客", false)
    reject_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    reject_btn.pressed.connect(_reject)
    deal_row.add_child(reject_btn)

    var notice_panel := PanelContainer.new()
    notice_panel.add_theme_stylebox_override("panel", panel_style(Color("eee7db"), 10, Color("eee7db")))
    box.add_child(notice_panel)
    notice_label = add_text(notice_panel, "每位客人只有 3 点鉴定精力。", 11, MUTED)

func build_stock(parent: VBoxContainer) -> void:
    add_text(parent, "库房 · 现金比藏品更重要", 15, INK)
    inventory_box = VBoxContainer.new()
    inventory_box.add_theme_constant_override("separation", 8)
    parent.add_child(inventory_box)

func build_market(parent: VBoxContainer) -> void:
    add_text(parent, "今日行情", 15, INK)
    market_grid = GridContainer.new()
    market_grid.columns = 2
    market_grid.add_theme_constant_override("h_separation", 8)
    market_grid.add_theme_constant_override("v_separation", 8)
    parent.add_child(market_grid)
    var p := PanelContainer.new()
    p.add_theme_stylebox_override("panel", panel_style(Color("fff7e9"), 12, Color("cdbb95")))
    parent.add_child(p)
    add_text(p, "同一件东西没有永远固定的成交价。热门品类更容易卖高，冷门品类会被压价。后续再加入鬼市、拍卖会和私人收藏家。", 11, MUTED)

func build_people(parent: VBoxContainer) -> void:
    add_text(parent, "人脉 · 先少而有用", 15, INK)
    for entry in [["陈敬之 · 老鉴定师","专长：瓷器、玉器 · 复核一次 ¥120"],["韩四海 · 二手商","出货快，但压价狠 · 后续解锁"]]:
        var p := PanelContainer.new()
        p.add_theme_stylebox_override("panel", panel_style(CARD, 13, LINE))
        parent.add_child(p)
        var vb := VBoxContainer.new()
        p.add_child(vb)
        add_text(vb, entry[0], 14, INK)
        add_text(vb, entry[1], 11, MUTED)

func build_tabs() -> void:
    var tabs := HBoxContainer.new()
    tabs.add_theme_constant_override("separation", 6)
    root_box.add_child(tabs)
    for entry in [["desk","收货台"],["stock","库房"],["market","行情"],["people","人脉"]]:
        var b := make_button(entry[1], entry[0] == "desk")
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.pressed.connect(_switch_view.bind(entry[0]))
        b.set_meta("view", entry[0])
        tabs.add_child(b)

func _switch_view(name: String) -> void:
    current_view = name
    desk_view.visible = name == "desk"
    stock_view.visible = name == "stock"
    market_view.visible = name == "market"
    people_view.visible = name == "people"
    render_all()

func make_item() -> Dictionary:
    var base: Dictionary = item_defs.pick_random().duplicate(true)
    var p: Dictionary = people.pick_random().duplicate(true)
    var auth := randf() < 0.54
    var value := randi_range(base["true_min"], base["true_max"]) if auth else randi_range(base["fake_min"], base["fake_max"])
    var ask_mult := randf_range(1.05, 1.8) if auth else randf_range(2.5, 8.5)
    var item := {
        "id": str(Time.get_unix_time_from_system()) + "-" + str(randi()),
        "name": base["name"], "cat": base["cat"], "shape": base["shape"],
        "auth": auth, "true_value": value, "ask": max(80, int(value * ask_mult)),
        "person": p, "quote": p["quote"], "energy": 3, "revealed": [], "clues": {},
        "offer": 0, "deal": 0, "patience": p["patience"], "expert": false, "buy_price": 0
    }
    for key in clue_names.keys():
        var use_true := auth
        if randf() < 0.14:
            use_true = not use_true
        item["clues"][key] = clue_bank[key]["t" if use_true else "f"].pick_random()
    return item

func _inspect(key: String) -> void:
    var c: Dictionary = state["current"]
    if c["energy"] <= 0 or key in c["revealed"]:
        return
    c["energy"] -= 1
    c["revealed"].append(key)
    state["inspect_count"] = int(state.get("inspect_count", 0)) + 1
    state["eye"] = 1 + int(state["inspect_count"] / 12)
    save_game()
    render_desk()

func _quick_offer(ratio: float) -> void:
    var c: Dictionary = state["current"]
    offer_input.text = str(max(1, int(c["ask"] * ratio)))

func _offer() -> void:
    var c: Dictionary = state["current"]
    var price := int(offer_input.text)
    if price <= 0:
        show_result("报价无效", "报价至少要大于 0。")
        return
    c["offer"] = price
    c["patience"] = int(c["patience"]) - 1
    var floor_price := float(c["ask"]) * float(c["person"]["flex"]) * randf_range(0.92, 1.04)
    if price >= floor_price:
        c["deal"] = min(price, int(c["ask"]))
        notice_label.text = c["person"]["name"] + "沉默了几秒：\n“行，就按这个价。”"
    elif c["patience"] <= 0:
        show_result("谈崩了", c["person"]["name"] + "把东西收了回去，转身离开。")
        next_customer()
        return
    else:
        c["ask"] = min(int(c["ask"]), int(max(price * 1.12, float(c["ask"]) * (float(c["person"]["flex"]) + randf_range(0.0, 0.05)))))
        notice_label.text = "卖家摇头：\n“这个价真不行。你再加一点，我也让一步。”"
    save_game()
    render_desk()

func _buy() -> void:
    var c: Dictionary = state["current"]
    if int(c["deal"]) <= 0:
        return
    if int(state["cash"]) < int(c["deal"]):
        show_result("现金不够", "古玩行最怕仓库里全是宝，手里却没有现金。")
        return
    state["cash"] = int(state["cash"]) - int(c["deal"])
    c["buy_price"] = int(c["deal"])
    state["inventory"].push_front(c.duplicate(true))
    show_result("收货入库", c["name"] + " 已入库。真假依然没有揭晓。")
    next_customer()

func _reject() -> void:
    next_customer()

func next_customer() -> void:
    state["visitor"] = int(state["visitor"]) + 1
    if int(state["visitor"]) > int(state["max_visitor"]):
        state["visitor"] = 1
        state["day"] = int(state["day"]) + 1
        state["cash"] = max(0, int(state["cash"]) - 80)
        random_market(true)
    state["current"] = make_item()
    save_game()
    render_all()

func random_market(show_message: bool) -> void:
    var hottest := ""
    var coldest := ""
    var high := 0.0
    var low := 99.0
    for key in state["market"].keys():
        var v := snappedf(randf_range(0.82, 1.20), 0.01)
        state["market"][key] = v
        if v > high:
            high = v
            hottest = key
        if v < low:
            low = v
            coldest = key
    if is_instance_valid(event_label):
        event_label.text = "今日消息：%s走热，%s偏冷。" % [hottest, coldest]
    if show_message:
        show_result("打烊", "扣除房租杂费 ¥80。新的一天行情已经变化。")

func _expert(index: int) -> void:
    if int(state["cash"]) < 120:
        show_result("现金不足", "专家复核需要 ¥120。")
        return
    var item: Dictionary = state["inventory"][index]
    if item.get("expert", false):
        show_result("已经复核", "这件货已经请专家看过。")
        return
    state["cash"] = int(state["cash"]) - 120
    item["expert"] = true
    var text := "器物核心工艺与年代特征基本吻合。" if item["auth"] else "多处细节互相打架，建议按赝品处理。"
    show_result("专家复核", text)
    save_game()
    render_all()

func _sell(index: int) -> void:
    var item: Dictionary = state["inventory"][index]
    var multiplier := float(state["market"].get(item["cat"], 1.0))
    var sold := int(float(item["true_value"]) * multiplier * randf_range(0.82, 1.16))
    var profit := sold - int(item["buy_price"])
    state["cash"] = int(state["cash"]) + sold
    state["rep"] = int(state["rep"]) + (1 if item["auth"] else -1)
    state["inventory"].remove_at(index)
    var verdict := "真品" if item["auth"] else "赝品"
    var ptext := ("赚了 " + money(profit)) if profit >= 0 else ("亏了 " + money(-profit))
    show_result(verdict + "出手", "%s 成交 %s，%s。" % [item["name"], money(sold), ptext])
    save_game()
    render_all()

func render_all() -> void:
    render_stats()
    if current_view == "desk": render_desk()
    if current_view == "stock": render_inventory()
    if current_view == "market": render_market()

func render_stats() -> void:
    if stats_labels.is_empty(): return
    stats_labels["day"].text = "第 %d 日" % int(state["day"])
    stats_labels["cash"].text = money(int(state["cash"]))
    stats_labels["rep"].text = str(state["rep"])
    stats_labels["eye"].text = "%d级" % int(state["eye"])

func render_desk() -> void:
    if state.get("current", {}).is_empty():
        state["current"] = make_item()
    var c: Dictionary = state["current"]
    var p: Dictionary = c["person"]
    visitor_label.text = "第 %d/%d 位" % [int(state["visitor"]), int(state["max_visitor"])]
    avatar_label.text = p["initial"]
    customer_name.text = p["name"]
    customer_desc.text = p["desc"] + " · " + p["trait"]
    quote_label.text = "“" + c["quote"] + "”"
    item_name.text = c["name"]
    item_sub.text = c["cat"] + " · 来历未明 · 未鉴定"
    artifact_view.set_shape(c["shape"])
    energy_label.text = "鉴定精力 %d/3" % int(c["energy"])
    ask_label.text = "卖家开价：" + money(int(c["ask"]))
    talk_label.text = ("谈成 " + money(int(c["deal"]))) if int(c["deal"]) > 0 else "暂未议价"
    if offer_input.text.is_empty() or int(c.get("offer", 0)) == 0:
        offer_input.text = str(max(1, int(int(c["ask"]) * 0.58)))
    buy_button.disabled = int(c["deal"]) <= 0

    clear_children(checks_grid)
    for key in clue_names.keys():
        var done := key in c["revealed"]
        var b := make_button(("✓ " if done else "") + clue_names[key], false)
        b.disabled = done or int(c["energy"]) <= 0
        b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        b.pressed.connect(_inspect.bind(key))
        checks_grid.add_child(b)

    clear_children(clues_box)
    for key in c["revealed"]:
        var pbox := PanelContainer.new()
        pbox.add_theme_stylebox_override("panel", panel_style(Color("f9f4eb"), 9, Color("cdbfa9")))
        clues_box.add_child(pbox)
        var row := HBoxContainer.new()
        pbox.add_child(row)
        var l := add_text(row, c["clues"][key], 11, INK)
        l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        add_text(row, clue_names[key], 10, MUTED)

    notice_label.text = "提示：线索不是百分百可靠，赝品也可能把某一处做得很像。" if int(c["deal"]) <= 0 else "价格已经谈成。你仍然可以拒收；收下后才真正占用现金。"

func render_inventory() -> void:
    clear_children(inventory_box)
    if state["inventory"].is_empty():
        add_text(inventory_box, "库房还是空的。\n真正的压力不是有没有宝，而是现金能不能撑到卖出去。", 12, MUTED)
        return
    for i in range(state["inventory"].size()):
        var item: Dictionary = state["inventory"][i]
        var p := PanelContainer.new()
        p.add_theme_stylebox_override("panel", panel_style(CARD, 13, LINE))
        inventory_box.add_child(p)
        var vb := VBoxContainer.new()
        vb.add_theme_constant_override("separation", 5)
        p.add_child(vb)
        var row := HBoxContainer.new()
        vb.add_child(row)
        var title := add_text(row, item["name"], 14, INK)
        title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        var badge := "未复核"
        if item.get("expert", false): badge = "专家：偏真" if item["auth"] else "专家：偏假"
        add_text(row, badge, 11, GOOD if item.get("expert", false) and item["auth"] else MUTED)
        add_text(vb, "%s · 收货 %s · 行情×%.2f" % [item["cat"], money(int(item["buy_price"])), float(state["market"].get(item["cat"],1.0))], 11, MUTED)
        var acts := HBoxContainer.new()
        acts.add_theme_constant_override("separation", 6)
        vb.add_child(acts)
        var eb := make_button("专家复核 ¥120", false)
        eb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        eb.pressed.connect(_expert.bind(i))
        acts.add_child(eb)
        var sb := make_button("按今日行情出手", false)
        sb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        sb.pressed.connect(_sell.bind(i))
        acts.add_child(sb)

func render_market() -> void:
    clear_children(market_grid)
    for key in state["market"].keys():
        var v := float(state["market"][key])
        var p := PanelContainer.new()
        p.add_theme_stylebox_override("panel", panel_style(CARD, 12, LINE))
        market_grid.add_child(p)
        var vb := VBoxContainer.new()
        p.add_child(vb)
        add_text(vb, key, 14, INK)
        var trend := "— 平稳"
        var color := MUTED
        if v > 1.10:
            trend = "▲ 热门"
            color = BAD
        elif v < 0.90:
            trend = "▼ 偏冷"
            color = Color("55738d")
        add_text(vb, "%s · ×%.2f" % [trend, v], 11, color)

func clear_children(node: Node) -> void:
    for child in node.get_children():
        child.queue_free()

func money(value: int) -> String:
    var s := str(abs(value))
    var out := ""
    var count := 0
    for i in range(s.length() - 1, -1, -1):
        if count > 0 and count % 3 == 0:
            out = "," + out
        out = s[i] + out
        count += 1
    return ("-¥" if value < 0 else "¥") + out

func show_result(title: String, text: String) -> void:
    if not is_instance_valid(result_dialog): return
    result_dialog.title = title
    result_dialog.dialog_text = text
    result_dialog.popup_centered(Vector2i(340, 190))

func save_game() -> void:
    var file := FileAccess.open("user://pawneye_save.json", FileAccess.WRITE)
    if file:
        file.store_string(JSON.stringify(state))

func load_game() -> void:
    if not FileAccess.file_exists("user://pawneye_save.json"):
        return
    var file := FileAccess.open("user://pawneye_save.json", FileAccess.READ)
    if not file:
        return
    var parsed = JSON.parse_string(file.get_as_text())
    if typeof(parsed) == TYPE_DICTIONARY and parsed.has("cash"):
        state = parsed
