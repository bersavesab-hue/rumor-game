#!/usr/bin/env bash
set -euo pipefail
GODOT_BIN="${GODOT_BIN:-godot}"
APK="build/whosaidit-v0.1.0-debug.apk"
mkdir -p build
"$GODOT_BIN" --headless --path . --import --quit
"$GODOT_BIN" --headless --path . --export-debug "Android" "$APK"
sha256sum "$APK" | tee build/SHA256SUMS.txt
echo "APK: $APK"
