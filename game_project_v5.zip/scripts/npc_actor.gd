class_name NpcActor
extends Button

signal npc_tapped(npc_id: int)

var npc_id: int = -1
var npc_name: String = ""
var target_position: Vector2
var base_color: Color = Color("#f8f0df")
var state_name: String = "idle"
var initials_label: Label

func _ready() -> void:
	focus_mode = Control.FOCUS_NONE
	custom_minimum_size = Vector2(34, 34)
	size = Vector2(34, 34)
	pivot_offset = size * 0.5
	pressed.connect(_on_pressed)
	mouse_entered.connect(func(): scale = Vector2(1.08, 1.08))
	mouse_exited.connect(func(): scale = Vector2.ONE)

func setup(id_value: int, display_name: String, start_position: Vector2, color: Color) -> void:
	npc_id = id_value
	npc_name = display_name
	position = start_position - size * 0.5
	target_position = position
	base_color = color
	text = display_name.substr(0, 1)
	tooltip_text = display_name
	set_state("idle")

func move_to(world_position: Vector2) -> void:
	target_position = world_position - size * 0.5

func _process(delta: float) -> void:
	position = position.lerp(target_position, clampf(delta * 3.0, 0.0, 1.0))

func set_state(value: String) -> void:
	state_name = value
	var style := StyleBoxFlat.new()
	style.bg_color = base_color
	style.corner_radius_top_left = 10
	style.corner_radius_top_right = 10
	style.corner_radius_bottom_left = 10
	style.corner_radius_bottom_right = 10
	style.border_width_left = 2
	style.border_width_top = 2
	style.border_width_right = 2
	style.border_width_bottom = 2
	match value:
		"heard":
			style.border_color = Color("#d69a4c")
		"believe":
			style.border_color = Color("#b94f43")
			style.border_width_left = 3
			style.border_width_top = 3
			style.border_width_right = 3
			style.border_width_bottom = 3
		"trace":
			style.border_color = Color("#4f78a2")
			style.border_width_left = 3
			style.border_width_top = 3
			style.border_width_right = 3
			style.border_width_bottom = 3
		"selected":
			style.border_color = Color("#e7c15c")
			style.border_width_left = 3
			style.border_width_top = 3
			style.border_width_right = 3
			style.border_width_bottom = 3
		_:
			style.border_color = Color("#514a41")
	add_theme_stylebox_override("normal", style)
	add_theme_stylebox_override("hover", style)
	add_theme_stylebox_override("pressed", style)
	add_theme_color_override("font_color", Color("#292622"))
	add_theme_font_size_override("font_size", 15)

func _on_pressed() -> void:
	npc_tapped.emit(npc_id)
