extends Control

var engine := RumorEngine.new()
var rng := RandomNumberGenerator.new()
var npcs: Array = []
var intel_list: Array = []
var selected_npc_id: int = 0
var selected_district: String = "tea"
var state := {
	"cash": 1200,
	"ap": 6,
	"minute": 8 * 60,
	"day": 1,
	"paused": false,
	"speed": 1,
	"last_intel_refresh_day": 1,
}

var district_order := ["market", "bank", "media", "home", "tea", "factory", "school", "mall", "office"]
var district_icons := {
	"market":"集", "bank":"银", "media":"媒",
	"home":"居", "tea":"馆", "factory":"厂",
	"school":"校", "mall":"街", "office":"楼"
}
var district_tints := {
	"market": Color("#ead39a"),
	"bank": Color("#d9e8d2"),
	"media": Color("#e7d9ea"),
	"home": Color("#edd8cb"),
	"tea": Color("#ead8b8"),
	"factory": Color("#d7e7ee"),
	"school": Color("#efddd4"),
	"mall": Color("#e3ebc7"),
	"office": Color("#d8d3ec")
}
var district_desc := {
	"market":"人流杂、熟人多，适合让消息先在本地交易圈发酵。",
	"bank":"敏感度高、求证快，一旦扩散也最容易留下明确痕迹。",
	"media":"传播强、放大快，适合冲热度，也最容易被反向追查。",
	"home":"小区聊天稳定、熟人链长，适合做慢热型扩散。",
	"tea":"茶馆与棋牌室消息密集，容易添油加醋，适合制造变化。",
	"factory":"班组传播稳定，若是企业类消息会很容易深化阶段。",
	"school":"家长群传播效率高，但求证和截图风险也偏高。",
	"mall":"客流广，口碑消息和消费类话题扩散更快。",
	"office":"白领圈子更理性，但一旦涉及金融和地产会放大很快。"
}

var colors := {
	"bg": Color("#131a1d"),
	"top": Color("#1b2327"),
	"paper": Color("#f8f2e7"),
	"paper2": Color("#f1e6d2"),
	"paper3": Color("#fffaf2"),
	"line": Color("#c7b496"),
	"ink": Color("#27231f"),
	"muted": Color("#73685b"),
	"accent": Color("#cc8c3d"),
	"accent2": Color("#3e6275"),
	"danger": Color("#b65246"),
	"green": Color("#5b7e66"),
	"nav": Color("#172025")
}

var top_time: Label
var top_cash: Label
var top_ap: Label

var district_buttons: Dictionary = {}
var district_hot_labels: Dictionary = {}
var district_stat_labels: Dictionary = {}
var district_preview_boxes: Dictionary = {}

var focus_title: Label
var focus_desc_label: Label
var focus_meta_label: Label
var selected_hint: Label
var npc_list_box: VBoxContainer

var rumor_subject: Label
var rumor_domain: Label
var rumor_text: Label
var heat_bar: ProgressBar
var trace_bar: ProgressBar
var exposure_bar: ProgressBar
var heat_value: Label
var trace_value: Label
var exposure_value: Label

var open_intel_button: Button
var spread_button: Button
var cool_button: Button
var trace_button: Button
var decoy_button: Button
var profile_button: Button

var overlay: ColorRect
var sheet: PanelContainer
var sheet_title: Label
var sheet_body: VBoxContainer
var event_panel: PanelContainer
var event_title: Label
var event_text: Label
var sim_timer: Timer
var event_hide_timer: Timer

func _ready() -> void:
	rng.randomize()
	_setup_theme()
	_build_ui()
	_generate_npcs(96)
	_refresh_intel()
	_select_district("tea")
	_refresh_all()
	_start_simulation()
	_show_event("v0.2 UI 重构版", "先从小镇概览选地点，再在地点详情里挑人；情报、追查和人物都收进了独立面板。")

func _setup_theme() -> void:
	var system_font := SystemFont.new()
	system_font.font_names = PackedStringArray(["Noto Sans CJK SC", "Noto Sans SC", "Noto Sans", "sans-serif"])
	system_font.font_weight = 500
	var game_theme := Theme.new()
	game_theme.default_font = system_font
	game_theme.default_font_size = 14
	theme = game_theme

func _build_ui() -> void:
	var bg := ColorRect.new()
	bg.color = colors.bg
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)

	var main_v := VBoxContainer.new()
	main_v.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	main_v.add_theme_constant_override("separation", 0)
	add_child(main_v)

	_build_topbar(main_v)
	_build_main_scroll(main_v)
	_build_bottom_nav(main_v)
	_build_sheet_overlay()
	_build_event_banner()

func _build_topbar(parent: VBoxContainer) -> void:
	var top := PanelContainer.new()
	top.custom_minimum_size = Vector2(0, 72)
	top.add_theme_stylebox_override("panel", _style(colors.top, 0, Color.TRANSPARENT, 0))
	parent.add_child(top)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 12)
	margin.add_theme_constant_override("margin_right", 12)
	margin.add_theme_constant_override("margin_top", 8)
	margin.add_theme_constant_override("margin_bottom", 8)
	top.add_child(margin)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 10)
	margin.add_child(row)

	var mark := Label.new()
	mark.text = "传"
	mark.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	mark.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	mark.custom_minimum_size = Vector2(42, 42)
	mark.add_theme_font_size_override("font_size", 22)
	mark.add_theme_color_override("font_color", colors.ink)
	mark.add_theme_stylebox_override("normal", _style(Color("#ecd7b3"), 13, Color.TRANSPARENT, 0))
	row.add_child(mark)

	var title_box := VBoxContainer.new()
	title_box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title_box.add_theme_constant_override("separation", -2)
	row.add_child(title_box)

	var title := Label.new()
	title.text = "这消息谁传的？"
	title.add_theme_font_size_override("font_size", 18)
	title.add_theme_color_override("font_color", Color.WHITE)
	title_box.add_child(title)

	var sub := Label.new()
	sub.text = "信息操盘 · 舆论追查 · 小镇沙盒"
	sub.add_theme_font_size_override("font_size", 10)
	sub.add_theme_color_override("font_color", Color("#b2bcbf"))
	title_box.add_child(sub)

	var stats := HBoxContainer.new()
	stats.add_theme_constant_override("separation", 6)
	row.add_child(stats)
	top_time = _top_chip(stats, "第1天 08:00", "时间")
	top_cash = _top_chip(stats, "¥1200", "资金")
	top_ap = _top_chip(stats, "6", "行动")

func _top_chip(parent: Control, value: String, caption: String) -> Label:
	var p := PanelContainer.new()
	p.custom_minimum_size = Vector2(72, 44)
	p.add_theme_stylebox_override("panel", _style(Color("#ffffff10"), 11, Color("#ffffff16"), 1))
	parent.add_child(p)
	var v := VBoxContainer.new()
	v.alignment = BoxContainer.ALIGNMENT_CENTER
	v.add_theme_constant_override("separation", -2)
	p.add_child(v)
	var val := Label.new()
	val.text = value
	val.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	val.add_theme_font_size_override("font_size", 11)
	val.add_theme_color_override("font_color", Color.WHITE)
	v.add_child(val)
	var cap := Label.new()
	cap.text = caption
	cap.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	cap.add_theme_font_size_override("font_size", 8)
	cap.add_theme_color_override("font_color", Color("#aab5b8"))
	v.add_child(cap)
	return val

func _build_main_scroll(parent: VBoxContainer) -> void:
	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	parent.add_child(scroll)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 10)
	margin.add_theme_constant_override("margin_right", 10)
	margin.add_theme_constant_override("margin_top", 10)
	margin.add_theme_constant_override("margin_bottom", 10)
	scroll.add_child(margin)

	var content := VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 10)
	margin.add_child(content)

	_build_town_overview(content)
	_build_focus_panel(content)
	_build_rumor_panel(content)
	_build_actions_panel(content)

func _build_town_overview(parent: VBoxContainer) -> void:
	var card := _card()
	parent.add_child(card)
	var v := _card_vbox(card)

	var title := Label.new()
	title.text = "小镇概览"
	title.add_theme_font_size_override("font_size", 16)
	title.add_theme_color_override("font_color", colors.ink)
	v.add_child(title)
	_add_small(v, "地图层不再堆满 NPC。先选地点，再看该地点的可接触人物和传播环境。")

	var grid := GridContainer.new()
	grid.columns = 3
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	v.add_child(grid)

	for key in district_order:
		var btn := Button.new()
		btn.text = ""
		btn.focus_mode = Control.FOCUS_NONE
		btn.custom_minimum_size = Vector2(0, 108)
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.add_child(btn)
		btn.pressed.connect(_on_district_button.bind(key))
		district_buttons[key] = btn

		var inner := MarginContainer.new()
		inner.add_theme_constant_override("margin_left", 8)
		inner.add_theme_constant_override("margin_right", 8)
		inner.add_theme_constant_override("margin_top", 8)
		inner.add_theme_constant_override("margin_bottom", 8)
		btn.add_child(inner)

		var box := VBoxContainer.new()
		box.add_theme_constant_override("separation", 4)
		inner.add_child(box)

		var top := HBoxContainer.new()
		box.add_child(top)

		var icon := Label.new()
		icon.text = str(district_icons.get(key, "点"))
		icon.custom_minimum_size = Vector2(26, 26)
		icon.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		icon.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		icon.add_theme_font_size_override("font_size", 14)
		icon.add_theme_color_override("font_color", colors.ink)
		icon.add_theme_stylebox_override("normal", _style(Color("#ffffff99"), 8, Color.TRANSPARENT, 0))
		top.add_child(icon)

		var hot := Label.new()
		hot.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hot.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		hot.add_theme_font_size_override("font_size", 8)
		hot.add_theme_color_override("font_color", colors.muted)
		top.add_child(hot)
		district_hot_labels[key] = hot

		var name_label := Label.new()
		name_label.text = str(DomainData.district_names()[key])
		name_label.add_theme_font_size_override("font_size", 11)
		name_label.add_theme_color_override("font_color", colors.ink)
		box.add_child(name_label)

		var stats := Label.new()
		stats.text = "—"
		stats.add_theme_font_size_override("font_size", 9)
		stats.add_theme_color_override("font_color", colors.muted)
		box.add_child(stats)
		district_stat_labels[key] = stats

		var preview := HBoxContainer.new()
		preview.add_theme_constant_override("separation", 4)
		box.add_child(preview)
		district_preview_boxes[key] = preview

func _build_focus_panel(parent: VBoxContainer) -> void:
	var card := _card()
	parent.add_child(card)
	var v := _card_vbox(card)

	var title_row := HBoxContainer.new()
	v.add_child(title_row)
	focus_title = Label.new()
	focus_title.text = "地点详情"
	focus_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	focus_title.add_theme_font_size_override("font_size", 16)
	focus_title.add_theme_color_override("font_color", colors.ink)
	title_row.add_child(focus_title)

	var focus_tag := Label.new()
	focus_tag.text = "选人"
	focus_tag.add_theme_font_size_override("font_size", 9)
	focus_tag.add_theme_stylebox_override("normal", _style(Color("#e4efe6"), 8, Color.TRANSPARENT, 0))
	focus_tag.add_theme_color_override("font_color", colors.green)
	title_row.add_child(focus_tag)

	focus_desc_label = Label.new()
	focus_desc_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	focus_desc_label.add_theme_font_size_override("font_size", 10)
	focus_desc_label.add_theme_color_override("font_color", colors.muted)
	v.add_child(focus_desc_label)

	focus_meta_label = Label.new()
	focus_meta_label.add_theme_font_size_override("font_size", 10)
	focus_meta_label.add_theme_color_override("font_color", colors.ink)
	v.add_child(focus_meta_label)

	selected_hint = Label.new()
	selected_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	selected_hint.add_theme_font_size_override("font_size", 10)
	selected_hint.add_theme_color_override("font_color", colors.accent2)
	v.add_child(selected_hint)

	var sec := Label.new()
	sec.text = "推荐接触人物"
	sec.add_theme_font_size_override("font_size", 12)
	sec.add_theme_color_override("font_color", colors.ink)
	v.add_child(sec)

	npc_list_box = VBoxContainer.new()
	npc_list_box.add_theme_constant_override("separation", 7)
	v.add_child(npc_list_box)

func _build_rumor_panel(parent: VBoxContainer) -> void:
	var card := _card()
	parent.add_child(card)
	var v := _card_vbox(card)

	var head := HBoxContainer.new()
	v.add_child(head)
	var t := Label.new()
	t.text = "当前消息"
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	t.add_theme_font_size_override("font_size", 16)
	t.add_theme_color_override("font_color", colors.ink)
	head.add_child(t)

	rumor_domain = Label.new()
	rumor_domain.text = "等待"
	rumor_domain.add_theme_font_size_override("font_size", 9)
	rumor_domain.add_theme_color_override("font_color", colors.accent2)
	rumor_domain.add_theme_stylebox_override("normal", _style(Color("#dbe8ee"), 8, Color.TRANSPARENT, 0))
	head.add_child(rumor_domain)

	rumor_subject = Label.new()
	rumor_subject.text = "暂无活跃消息"
	rumor_subject.add_theme_font_size_override("font_size", 13)
	rumor_subject.add_theme_color_override("font_color", colors.ink)
	v.add_child(rumor_subject)

	rumor_text = Label.new()
	rumor_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	rumor_text.add_theme_font_size_override("font_size", 10)
	rumor_text.add_theme_color_override("font_color", colors.muted)
	v.add_child(rumor_text)

	var metrics := GridContainer.new()
	metrics.columns = 3
	metrics.add_theme_constant_override("h_separation", 6)
	metrics.add_theme_constant_override("v_separation", 4)
	v.add_child(metrics)
	var triplet = _metric_row(metrics, "热度", colors.accent)
	heat_bar = triplet[0]
	heat_value = triplet[1]
	triplet = _metric_row(metrics, "追查", colors.accent2)
	trace_bar = triplet[0]
	trace_value = triplet[1]
	triplet = _metric_row(metrics, "暴露", colors.danger)
	exposure_bar = triplet[0]
	exposure_value = triplet[1]

func _build_actions_panel(parent: VBoxContainer) -> void:
	var card := _card()
	parent.add_child(card)
	var v := _card_vbox(card)

	var title := Label.new()
	title.text = "操作台"
	title.add_theme_font_size_override("font_size", 16)
	title.add_theme_color_override("font_color", colors.ink)
	v.add_child(title)
	_add_small(v, "核心循环：拿情报 → 选地点 → 挑人下手 → 观察扩散 → 压热度 / 干扰追查。")

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	v.add_child(grid)

	open_intel_button = _action_button(grid, "打开情报市场", true)
	open_intel_button.pressed.connect(func(): _open_sheet("intel"))

	spread_button = _action_button(grid, "推给已选人物", true)
	spread_button.pressed.connect(_on_manual_spread)

	cool_button = _action_button(grid, "主动降温")
	cool_button.pressed.connect(_on_cool_down)

	trace_button = _action_button(grid, "查看追查链")
	trace_button.pressed.connect(func(): _open_sheet("trace"))

	decoy_button = _action_button(grid, "制造假线索")
	decoy_button.pressed.connect(_on_decoy)

	profile_button = _action_button(grid, "查看人物档案")
	profile_button.pressed.connect(func(): _open_sheet("profile"))

func _metric_row(parent: GridContainer, caption: String, color: Color) -> Array:
	var cap := Label.new()
	cap.text = caption
	cap.add_theme_font_size_override("font_size", 9)
	cap.add_theme_color_override("font_color", colors.muted)
	parent.add_child(cap)

	var bar := ProgressBar.new()
	bar.min_value = 0
	bar.max_value = 100
	bar.value = 0
	bar.show_percentage = false
	bar.custom_minimum_size = Vector2(0, 8)
	bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bar.add_theme_stylebox_override("background", _style(Color("#e1d5c1"), 6, Color.TRANSPARENT, 0))
	bar.add_theme_stylebox_override("fill", _style(color, 6, Color.TRANSPARENT, 0))
	parent.add_child(bar)

	var val := Label.new()
	val.text = "0"
	val.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	val.add_theme_font_size_override("font_size", 9)
	val.add_theme_color_override("font_color", colors.ink)
	parent.add_child(val)
	return [bar, val]

func _action_button(parent: Control, label_text: String, primary: bool = false) -> Button:
	var b := Button.new()
	b.text = label_text
	b.focus_mode = Control.FOCUS_NONE
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.custom_minimum_size = Vector2(0, 42)
	b.add_theme_font_size_override("font_size", 10)
	b.add_theme_color_override("font_color", colors.ink)
	var bg: Color = Color("#f4e4c9") if primary else colors.paper3
	var border: Color = Color("#b98a4d") if primary else colors.line
	b.add_theme_stylebox_override("normal", _style(bg, 10, border, 1))
	b.add_theme_stylebox_override("hover", _style(bg.lightened(0.03), 10, border, 1))
	b.add_theme_stylebox_override("pressed", _style(bg.darkened(0.04), 10, border, 1))
	parent.add_child(b)
	return b

func _build_bottom_nav(parent: VBoxContainer) -> void:
	var nav := PanelContainer.new()
	nav.custom_minimum_size = Vector2(0, 66)
	nav.add_theme_stylebox_override("panel", _style(colors.nav, 0, Color("#ffffff12"), 1))
	parent.add_child(nav)

	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 2)
	nav.add_child(row)

	for item in [["镇","小镇","town"],["讯","情报","intel"],["网","关系","network"],["查","追查","trace"],["人","人物","profile"]]:
		var b := Button.new()
		b.text = "%s\n%s" % [item[0], item[1]]
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.focus_mode = Control.FOCUS_NONE
		b.add_theme_font_size_override("font_size", 9)
		b.add_theme_color_override("font_color", Color("#c5ced0"))
		b.add_theme_stylebox_override("normal", _style(Color.TRANSPARENT, 0, Color.TRANSPARENT, 0))
		b.add_theme_stylebox_override("pressed", _style(Color("#ffffff10"), 8, Color.TRANSPARENT, 0))
		var tab: String = item[2]
		b.pressed.connect(_on_nav_pressed.bind(tab))
		row.add_child(b)

func _build_sheet_overlay() -> void:
	overlay = ColorRect.new()
	overlay.color = Color("#0b0e0f8c")
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.visible = false
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(overlay)

	sheet = PanelContainer.new()
	sheet.anchor_left = 0.03
	sheet.anchor_right = 0.97
	sheet.anchor_top = 0.12
	sheet.anchor_bottom = 0.97
	sheet.add_theme_stylebox_override("panel", _style(colors.paper, 22, Color("#c8b495"), 1))
	overlay.add_child(sheet)

	var vm := VBoxContainer.new()
	vm.add_theme_constant_override("separation", 0)
	sheet.add_child(vm)

	var sh := PanelContainer.new()
	sh.custom_minimum_size = Vector2(0, 56)
	sh.add_theme_stylebox_override("panel", _style(colors.paper2, 20, Color.TRANSPARENT, 0))
	vm.add_child(sh)

	var hm := MarginContainer.new()
	hm.add_theme_constant_override("margin_left", 12)
	hm.add_theme_constant_override("margin_right", 10)
	hm.add_theme_constant_override("margin_top", 8)
	hm.add_theme_constant_override("margin_bottom", 8)
	sh.add_child(hm)

	var hr := HBoxContainer.new()
	hm.add_child(hr)
	sheet_title = Label.new()
	sheet_title.text = "面板"
	sheet_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sheet_title.add_theme_font_size_override("font_size", 16)
	sheet_title.add_theme_color_override("font_color", colors.ink)
	hr.add_child(sheet_title)

	var close := Button.new()
	close.text = "关闭"
	close.focus_mode = Control.FOCUS_NONE
	close.add_theme_font_size_override("font_size", 10)
	close.add_theme_color_override("font_color", Color.WHITE)
	close.add_theme_stylebox_override("normal", _style(Color("#45423d"), 10, Color.TRANSPARENT, 0))
	close.pressed.connect(_close_sheet)
	hr.add_child(close)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vm.add_child(scroll)

	var body_margin := MarginContainer.new()
	body_margin.add_theme_constant_override("margin_left", 10)
	body_margin.add_theme_constant_override("margin_right", 10)
	body_margin.add_theme_constant_override("margin_top", 10)
	body_margin.add_theme_constant_override("margin_bottom", 24)
	scroll.add_child(body_margin)

	sheet_body = VBoxContainer.new()
	sheet_body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sheet_body.add_theme_constant_override("separation", 8)
	body_margin.add_child(sheet_body)

func _build_event_banner() -> void:
	event_panel = PanelContainer.new()
	event_panel.anchor_left = 0.05
	event_panel.anchor_right = 0.95
	event_panel.anchor_top = 0.09
	event_panel.anchor_bottom = 0.17
	event_panel.add_theme_stylebox_override("panel", _style(Color("#232a2df2"), 14, Color("#ffffff18"), 1))
	event_panel.visible = false
	add_child(event_panel)

	var m := MarginContainer.new()
	m.add_theme_constant_override("margin_left", 10)
	m.add_theme_constant_override("margin_right", 10)
	m.add_theme_constant_override("margin_top", 8)
	m.add_theme_constant_override("margin_bottom", 8)
	event_panel.add_child(m)

	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 1)
	m.add_child(v)

	event_title = Label.new()
	event_title.add_theme_font_size_override("font_size", 11)
	event_title.add_theme_color_override("font_color", Color.WHITE)
	v.add_child(event_title)

	event_text = Label.new()
	event_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	event_text.add_theme_font_size_override("font_size", 9)
	event_text.add_theme_color_override("font_color", Color("#d5dfe1"))
	v.add_child(event_text)

	event_hide_timer = Timer.new()
	event_hide_timer.one_shot = true
	event_hide_timer.wait_time = 3.8
	event_hide_timer.timeout.connect(func(): event_panel.visible = false)
	add_child(event_hide_timer)

func _generate_npcs(count: int) -> void:
	npcs.clear()
	var names: Array[String] = DomainData.names()
	var jobs_map: Dictionary = DomainData.jobs_by_district()
	for i in count:
		var district: String = district_order[i % district_order.size()]
		var new_npc := {
			"id": i,
			"name": names[i % names.size()] + ("" if i < names.size() else str(2 + i / names.size())),
			"district": district,
			"job": jobs_map[district][rng.randi_range(0, jobs_map[district].size() - 1)],
			"talk": rng.randi_range(20, 94),
			"skeptic": rng.randi_range(20, 95),
			"influence": rng.randi_range(18, 90),
			"traits": _sample_strings(DomainData.trait_pool(), 2),
			"social": _sample_strings(DomainData.social_pool(), 2),
			"friends": [],
			"heard": false,
			"belief": 0.0,
			"node": "",
			"last_spread": -9999,
			"spread_wait": rng.randi_range(30, 65),
			"rumor_depth": 0,
			"trace_aware": false,
		}
		npcs.append(new_npc)

	for npc in npcs:
		var friend_ids: Array = []
		while friend_ids.size() < 4:
			var candidate := rng.randi_range(0, npcs.size() - 1)
			if candidate != npc["id"] and not friend_ids.has(candidate):
				friend_ids.append(candidate)
		npc["friends"] = friend_ids

func _refresh_intel() -> void:
	intel_list = []
	var pool: Array = DomainData.intel_pool().duplicate(true)
	pool.shuffle()
	for i in mini(4, pool.size()):
		var item: Dictionary = pool[i].duplicate(true)
		item["confidence"] = rng.randi_range(35, 79)
		item["age"] = 0
		intel_list.append(item)

func _select_district(key: String) -> void:
	selected_district = key
	var options: Array = _district_npcs_sorted(key)
	if not options.is_empty():
		selected_npc_id = int(options[0]["id"])
	_refresh_all()

func _district_npcs_sorted(district: String) -> Array:
	var list: Array = []
	for npc in npcs:
		if npc["district"] == district:
			list.append(npc)
	list.sort_custom(func(a, b): return _npc_pick_score(a) > _npc_pick_score(b))
	return list

func _npc_pick_score(npc: Dictionary) -> float:
	var score := float(npc["influence"]) * 0.55 + float(npc["talk"]) * 0.35 - float(npc["skeptic"]) * 0.18
	if npc.get("social", []).has("爱发群聊"):
		score += 6.0
	if npc.get("social", []).has("爱直播"):
		score += 5.0
	if npc.get("heard", false):
		score -= 10.0
	if engine.has_active():
		score += engine.role_relevance(npc) * 30.0
	return score

func _start_simulation() -> void:
	sim_timer = Timer.new()
	sim_timer.wait_time = 0.85
	sim_timer.timeout.connect(_on_sim_tick)
	add_child(sim_timer)
	sim_timer.start()

func _on_sim_tick() -> void:
	if state["paused"]:
		return
	state["minute"] += 3 * int(state["speed"])
	if state["minute"] >= 24 * 60:
		state["minute"] -= 24 * 60
		state["day"] += 1
		state["ap"] = mini(9, int(state["ap"]) + 4)
		if int(state["last_intel_refresh_day"]) != int(state["day"]):
			_refresh_intel()
			state["last_intel_refresh_day"] = state["day"]
		_show_event("新的一天", "行动点恢复 4 点，情报市场也刷新了。")
	if engine.has_active():
		var spread_event: Dictionary = engine.auto_spread_step(npcs, state["minute"])
		if not spread_event.is_empty():
			_on_spread_event(spread_event)
		var trace_event: Dictionary = engine.trace_step(npcs, state["minute"])
		if not trace_event.is_empty():
			_on_trace_event(trace_event)
		engine.passive_decay()
	_refresh_all()

func _on_manual_spread() -> void:
	if not engine.has_active():
		_show_event("还没有消息", "先去情报市场拿一条消息。")
		return
	if int(state["ap"]) < 1:
		_show_event("行动点不足", "等到第二天恢复，或者先观察自然传播。")
		return
	var result: Dictionary = engine.manual_spread(npcs, selected_npc_id, state["minute"])
	if not result.get("ok", false):
		_show_event("这次没推成", result.get("reason", "无法传播"))
		return
	state["ap"] -= 1
	var n: Dictionary = npcs[selected_npc_id]
	_show_event("第一跳完成", "%s（%s）听到了消息。现在先观察他/她会怎么扩散。" % [n["name"], n["job"]])
	_refresh_all()

func _on_cool_down() -> void:
	if not engine.has_active():
		_show_event("当前没有消息", "没有活跃消息可降温。")
		return
	if int(state["ap"]) < 1:
		_show_event("行动点不足", "降温需要 1 点行动。")
		return
	state["ap"] -= 1
	engine.cool_down()
	_show_event("主动降温", "你停止推送，热度下降，追查压力也略有缓解。")
	_refresh_all()

func _on_decoy() -> void:
	if not engine.has_active():
		_show_event("当前没有消息", "没有必要放假线索。")
		return
	if int(state["ap"]) < 2 or int(state["cash"]) < 120:
		_show_event("资源不足", "假线索需要 2 行动点和 ¥120。")
		return
	state["ap"] -= 2
	state["cash"] -= 120
	engine.plant_decoy()
	_show_event("假线索已放出", "源头暴露下降，但追查者也会感觉到人为干预。")
	_refresh_all()

func _on_spread_event(event: Dictionary) -> void:
	var target_id := int(event.get("target", -1))
	if target_id >= 0 and event.get("changed", false):
		var label: String = _active_node_label(str(event.get("node", "")))
		_show_event("说法发生变化", "%s 把消息推进成了“%s”。" % [npcs[target_id]["name"], label])

func _on_trace_event(event: Dictionary) -> void:
	match event.get("kind", ""):
		"investigator":
			_show_event("有人开始追查", event.get("text", "追查开始"))
		"clue":
			var clue: Dictionary = event.get("clue", {})
			_show_event("追查推进", "调查者利用【%s】往源头靠近。" % clue.get("type", "线索"))

func _refresh_all() -> void:
	_refresh_topbar()
	_refresh_town_overview()
	_refresh_focus_panel()
	_refresh_rumor_panel()

func _refresh_topbar() -> void:
	top_time.text = _time_text()
	top_cash.text = "¥%d" % int(state["cash"])
	top_ap.text = str(state["ap"])

func _refresh_town_overview() -> void:
	for key in district_order:
		if not district_buttons.has(key):
			continue
		var btn: Button = district_buttons[key]
		var residents: Array = _district_npcs_sorted(key)
		var heard_count := 0
		var trace_count := 0
		for npc in residents:
			if npc.get("heard", false):
				heard_count += 1
			if npc.get("trace_aware", false):
				trace_count += 1
		district_stat_labels[key].text = "%d人 · 已传%d" % [residents.size(), heard_count]
		var tag := "普通"
		if engine.has_active() and DomainData.domains()[engine.active["domain"]]["districts"].has(key):
			tag = "相关"
		district_hot_labels[key].text = "%s · 查%d" % [tag, trace_count]

		var preview: HBoxContainer = district_preview_boxes[key]
		for child in preview.get_children():
			child.queue_free()
		for i in mini(3, residents.size()):
			var bubble := Label.new()
			bubble.text = str(residents[i]["name"]).substr(0, 1)
			bubble.custom_minimum_size = Vector2(22, 22)
			bubble.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			bubble.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
			bubble.add_theme_font_size_override("font_size", 10)
			bubble.add_theme_color_override("font_color", colors.ink)
			bubble.add_theme_stylebox_override("normal", _style(Color("#fffaf0dd"), 11, Color("#6b6054"), 1))
			preview.add_child(bubble)
		_apply_district_style(btn, key, key == selected_district)

func _apply_district_style(btn: Button, key: String, selected: bool) -> void:
	var fill: Color = district_tints.get(key, Color("#efe5d3"))
	var border: Color = Color("#6c6155")
	var width := 1
	if selected:
		fill = fill.lightened(0.08)
		border = Color("#d59a47")
		width = 3
	btn.add_theme_stylebox_override("normal", _style(fill, 16, border, width))
	btn.add_theme_stylebox_override("hover", _style(fill.lightened(0.03), 16, border, width))
	btn.add_theme_stylebox_override("pressed", _style(fill.darkened(0.03), 16, border, width))

func _refresh_focus_panel() -> void:
	focus_title.text = "地点详情 · %s" % DomainData.district_names()[selected_district]
	focus_desc_label.text = str(district_desc.get(selected_district, "暂无描述"))
	var residents: Array = _district_npcs_sorted(selected_district)
	var heard_count := 0
	for npc in residents:
		if npc.get("heard", false):
			heard_count += 1
	focus_meta_label.text = "地点居民 %d 人 · 当前已接触 %d 人" % [residents.size(), heard_count]

	var selected: Dictionary = npcs[selected_npc_id]
	selected_hint.text = "已选人物：%s · %s · 影响力%d / 传播欲%d / 求证%d" % [selected["name"], selected["job"], selected["influence"], selected["talk"], selected["skeptic"]]

	for child in npc_list_box.get_children():
		child.queue_free()

	for i in mini(4, residents.size()):
		var npc: Dictionary = residents[i]
		var card := PanelContainer.new()
		var border: Color = Color("#d59a47") if npc["id"] == selected_npc_id else Color(colors["line"])
		var width: int = 2 if npc["id"] == selected_npc_id else 1
		card.add_theme_stylebox_override("panel", _style(Color("#fffaf2"), 14, border, width))
		npc_list_box.add_child(card)
		var m := MarginContainer.new()
		m.add_theme_constant_override("margin_left", 8)
		m.add_theme_constant_override("margin_right", 8)
		m.add_theme_constant_override("margin_top", 8)
		m.add_theme_constant_override("margin_bottom", 8)
		card.add_child(m)
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 5)
		m.add_child(v)
		var row := HBoxContainer.new()
		v.add_child(row)
		var name := Label.new()
		name.text = "%s · %s" % [npc["name"], npc["job"]]
		name.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name.add_theme_font_size_override("font_size", 11)
		name.add_theme_color_override("font_color", colors.ink)
		row.add_child(name)
		var tag := Label.new()
		tag.text = "推荐值 %d" % int(round(_npc_pick_score(npc)))
		tag.add_theme_font_size_override("font_size", 8)
		tag.add_theme_color_override("font_color", colors.green)
		tag.add_theme_stylebox_override("normal", _style(Color("#e6f0e8"), 8, Color.TRANSPARENT, 0))
		row.add_child(tag)

		_add_small(v, "影响力 %d · 传播欲 %d · 求证 %d" % [npc["influence"], npc["talk"], npc["skeptic"]])
		_add_chips(v, npc["traits"] + npc["social"])
		var choose := Button.new()
		choose.text = "选中此人"
		_style_button(choose, npc["id"] == selected_npc_id)
		choose.pressed.connect(_on_choose_npc.bind(int(npc["id"])))
		v.add_child(choose)

func _refresh_rumor_panel() -> void:
	if not engine.has_active():
		rumor_subject.text = "暂无活跃消息"
		rumor_domain.text = "等待"
		rumor_text.text = "先去“情报市场”挑一条消息。不同消息会决定哪些地点和职业更容易接盘，也会改变追查强度。"
		_set_metric(heat_bar, heat_value, 0)
		_set_metric(trace_bar, trace_value, 0)
		_set_metric(exposure_bar, exposure_value, 0)
		return
	var a: Dictionary = engine.active
	rumor_subject.text = "%s · %s" % [a["subject"], _deepest_stage_label()]
	rumor_domain.text = str(a["domain_label"])
	rumor_text.text = str(a["text"]) + "\n最新状态：传播 %d 跳，追查者 %d 人。" % [a["spread_count"], a["investigators"].size()]
	_set_metric(heat_bar, heat_value, float(a["heat"]))
	_set_metric(trace_bar, trace_value, float(a["trace"]))
	_set_metric(exposure_bar, exposure_value, float(a["exposure"]))

func _set_metric(bar: ProgressBar, lab: Label, value: float) -> void:
	bar.value = value
	lab.text = str(roundi(value))

func _open_sheet(kind: String) -> void:
	overlay.visible = true
	for child in sheet_body.get_children():
		child.queue_free()
	match kind:
		"intel":
			_fill_intel_sheet()
		"network":
			_fill_network_sheet()
		"trace":
			_fill_trace_sheet()
		"profile":
			_fill_profile_sheet()
		_:
			_fill_town_sheet()

func _close_sheet() -> void:
	overlay.visible = false

func _fill_intel_sheet() -> void:
	sheet_title.text = "情报市场"
	_add_help("情报不是任务按钮，而是待下注的消息。先判断它适不适合你当前的小镇环境。")
	for item in intel_list:
		var card := _card()
		sheet_body.add_child(card)
		var v := _card_vbox(card)
		var head := HBoxContainer.new()
		v.add_child(head)
		var title := Label.new()
		title.text = "%s · %s" % [item["subject"], item["domain_label"]]
		title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		title.add_theme_font_size_override("font_size", 13)
		title.add_theme_color_override("font_color", colors.ink)
		head.add_child(title)
		var risk := Label.new()
		risk.text = "追查 %d" % item["base_trace"]
		risk.add_theme_font_size_override("font_size", 9)
		risk.add_theme_color_override("font_color", colors.danger)
		head.add_child(risk)
		_add_small(v, item["text"])
		_add_chips(v, ["来源：%s" % item["source"], "可信感 %d%%" % item["confidence"], "适合观察职业链反应"])
		var b := Button.new()
		b.text = "拿这条消息"
		_style_button(b, true)
		v.add_child(b)
		var data: Dictionary = item
		b.pressed.connect(_on_start_intel_pressed.bind(data))

func _start_intel(item: Dictionary) -> void:
	engine.start_intel(item, state["minute"])
	for npc in npcs:
		npc["heard"] = false
		npc["belief"] = 0.0
		npc["node"] = ""
		npc["last_spread"] = -9999
		npc["rumor_depth"] = 0
		npc["trace_aware"] = false
	_close_sheet()
	_refresh_all()
	_show_event("线索已入手", "%s 提供了一条未经完全证实的消息。现在去挑一个合适的第一跳人物。" % item["source"])

func _fill_network_sheet() -> void:
	sheet_title.text = "关系与传播节点"
	_add_help("这里展示小镇里最值得利用的人物。高影响力不一定最好；有些人传播快，但也会把你暴露得更快。")
	var ranked: Array = npcs.duplicate()
	ranked.sort_custom(func(a, b): return _npc_pick_score(a) > _npc_pick_score(b))
	for i in mini(14, ranked.size()):
		var n: Dictionary = ranked[i]
		var card := _card()
		sheet_body.add_child(card)
		var v := _card_vbox(card)
		var title := Label.new()
		title.text = "%s · %s · %s" % [n["name"], DomainData.district_names()[n["district"]], n["job"]]
		title.add_theme_font_size_override("font_size", 11)
		title.add_theme_color_override("font_color", colors.ink)
		v.add_child(title)
		_add_small(v, "推荐值 %d · 影响力 %d · 传播欲 %d · 求证 %d" % [int(round(_npc_pick_score(n))), n["influence"], n["talk"], n["skeptic"]])
		_add_chips(v, n["traits"] + n["social"])
		var b := Button.new()
		b.text = "跳到该地点并选中此人"
		_style_button(b, false)
		v.add_child(b)
		var id := int(n["id"])
		var district := str(n["district"])
		b.pressed.connect(_on_network_pick.bind(id, district))

func _fill_trace_sheet() -> void:
	sheet_title.text = "追查链"
	if not engine.has_active():
		_add_help("目前没有活跃消息。传播后，每一次当面转述、电话、群聊和短视频都会留下不同强度的痕迹。")
		return
	var a: Dictionary = engine.active
	var summary := _card()
	sheet_body.add_child(summary)
	var sv := _card_vbox(summary)
	var title := Label.new()
	title.text = "%s · %s" % [a["subject"], a["domain_label"]]
	title.add_theme_font_size_override("font_size", 13)
	title.add_theme_color_override("font_color", colors.ink)
	sv.add_child(title)
	_add_chips(sv, ["追查 %d" % roundi(a["trace"]), "暴露 %d" % roundi(a["exposure"]), "传播 %d 跳" % a["spread_count"], "追查者 %d" % a["investigators"].size()])
	_add_small(sv, "调查者不是瞬间锁定你，而是沿着公开节点、截图、通话关系和目击证词逐层回溯。")

	var clue_title := Label.new()
	clue_title.text = "现有痕迹"
	clue_title.add_theme_font_size_override("font_size", 13)
	clue_title.add_theme_color_override("font_color", colors.ink)
	sheet_body.add_child(clue_title)
	if a["clues"].is_empty():
		_add_help("当前还没有明显痕迹。")
	for clue in a["clues"].slice(maxi(0, a["clues"].size() - 8), a["clues"].size()):
		var card := _card()
		sheet_body.add_child(card)
		var v := _card_vbox(card)
		var line := Label.new()
		line.text = "线索·%s · 强度 %.1f · 距离源头 %d 跳" % [clue["type"], clue["strength"], clue["depth"]]
		line.add_theme_font_size_override("font_size", 10)
		line.add_theme_color_override("font_color", colors.ink)
		v.add_child(line)
		_add_small(v, clue["text"])

	var tl_title := Label.new()
	tl_title.text = "传播 / 追查时间线"
	tl_title.add_theme_font_size_override("font_size", 13)
	tl_title.add_theme_color_override("font_color", colors.ink)
	sheet_body.add_child(tl_title)
	for item in a["timeline"].slice(maxi(0, a["timeline"].size() - 16), a["timeline"].size()):
		var card := PanelContainer.new()
		card.add_theme_stylebox_override("panel", _style(Color("#fffaf1"), 10, colors.line, 1))
		sheet_body.add_child(card)
		var m := MarginContainer.new()
		m.add_theme_constant_override("margin_left", 8)
		m.add_theme_constant_override("margin_right", 8)
		m.add_theme_constant_override("margin_top", 8)
		m.add_theme_constant_override("margin_bottom", 8)
		card.add_child(m)
		var v := VBoxContainer.new()
		v.add_theme_constant_override("separation", 3)
		m.add_child(v)
		var tm := Label.new()
		tm.text = _minute_to_text(int(item["time"]))
		tm.add_theme_font_size_override("font_size", 9)
		tm.add_theme_color_override("font_color", colors.accent2)
		v.add_child(tm)
		var txt := Label.new()
		txt.text = item["text"]
		txt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		txt.add_theme_font_size_override("font_size", 10)
		txt.add_theme_color_override("font_color", colors.ink)
		v.add_child(txt)

func _fill_profile_sheet() -> void:
	sheet_title.text = "人物档案"
	var n: Dictionary = npcs[selected_npc_id]
	var card := _card()
	sheet_body.add_child(card)
	var v := _card_vbox(card)
	var title := Label.new()
	title.text = "%s · %s" % [n["name"], n["job"]]
	title.add_theme_font_size_override("font_size", 16)
	title.add_theme_color_override("font_color", colors.ink)
	v.add_child(title)
	_add_small(v, "%s · 影响力 %d · 传播欲 %d · 求证 %d" % [DomainData.district_names()[n["district"]], n["influence"], n["talk"], n["skeptic"]])
	_add_chips(v, n["traits"] + n["social"])
	_add_small(v, "熟人：" + "、".join(n["friends"].map(func(id): return npcs[int(id)]["name"])))
	if engine.has_active():
		var status := "尚未听说"
		if n["heard"]:
			status = "基本相信" if float(n["belief"]) > 0.62 else "半信半疑"
		_add_small(v, "对当前消息：%s · 当前语义：%s" % [status, _active_node_label(str(n["node"])) if not str(n["node"]).is_empty() else "—"])
		var preview_text: String = engine.generate_speech(n, str(n["node"]) if not str(n["node"]).is_empty() else str(engine.active["seed"]), "react")
		var pcard := _card()
		sheet_body.add_child(pcard)
		var pv := _card_vbox(pcard)
		var pt := Label.new()
		pt.text = "他/她可能会怎么说"
		pt.add_theme_font_size_override("font_size", 11)
		pt.add_theme_color_override("font_color", colors.ink)
		pv.add_child(pt)
		_add_small(pv, "“%s”" % preview_text)

func _fill_town_sheet() -> void:
	sheet_title.text = "小镇动态"
	_add_help("这里展示各地点的基础态势，方便你判断下一跳投放位置。")
	for key in district_order:
		var residents: Array = _district_npcs_sorted(key)
		var heard_count := 0
		for npc in residents:
			if npc.get("heard", false):
				heard_count += 1
		var card := _card()
		sheet_body.add_child(card)
		var v := _card_vbox(card)
		var title := Label.new()
		title.text = "%s · %s" % [district_icons.get(key, "点"), DomainData.district_names()[key]]
		title.add_theme_font_size_override("font_size", 12)
		title.add_theme_color_override("font_color", colors.ink)
		v.add_child(title)
		_add_small(v, "%s\n地点居民 %d 人 · 当前已接触 %d 人" % [district_desc.get(key, "暂无描述"), residents.size(), heard_count])

func _on_district_button(key: String) -> void:
	_select_district(key)

func _on_nav_pressed(tab: String) -> void:
	if tab == "town":
		_close_sheet()
	else:
		_open_sheet(tab)

func _on_choose_npc(id: int) -> void:
	selected_npc_id = id
	_refresh_all()

func _on_start_intel_pressed(data: Dictionary) -> void:
	_start_intel(data)

func _on_network_pick(id: int, district: String) -> void:
	selected_npc_id = id
	selected_district = district
	_close_sheet()
	_refresh_all()

func _deepest_stage_label() -> String:
	if not engine.has_active():
		return "—"
	var deepest := str(engine.active["seed"])
	var stage := 1
	for npc in npcs:
		if npc["heard"] and not str(npc["node"]).is_empty():
			var s := engine.node_stage(str(npc["node"]))
			if s > stage:
				stage = s
				deepest = str(npc["node"])
	return "%d级 · %s" % [stage, _active_node_label(deepest)]

func _active_node_label(node_key: String) -> String:
	if not engine.has_active() or node_key.is_empty():
		return "—"
	var d: Dictionary = DomainData.domains().get(engine.active["domain"], {})
	return str(d.get("nodes", {}).get(node_key, {}).get("label", node_key))

func _show_event(title: String, text: String) -> void:
	event_title.text = title
	event_text.text = text
	event_panel.visible = true
	event_hide_timer.start()

func _time_text() -> String:
	return "第%d天 %s" % [state["day"], _minute_to_text(state["minute"])]

func _minute_to_text(minute: int) -> String:
	return "%02d:%02d" % [int(minute / 60) % 24, minute % 60]

func _sample_strings(source: Array[String], count: int) -> Array[String]:
	var copy := source.duplicate()
	copy.shuffle()
	var out: Array[String] = []
	for i in mini(count, copy.size()):
		out.append(copy[i])
	return out

func _style(bg: Color, radius: int, border: Color, border_width: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.corner_radius_top_left = radius
	s.corner_radius_top_right = radius
	s.corner_radius_bottom_left = radius
	s.corner_radius_bottom_right = radius
	if border_width > 0:
		s.border_color = border
		s.border_width_left = border_width
		s.border_width_top = border_width
		s.border_width_right = border_width
		s.border_width_bottom = border_width
	return s

func _card() -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", _style(colors.paper, 16, colors.line, 1))
	return p

func _card_vbox(card: PanelContainer) -> VBoxContainer:
	var m := MarginContainer.new()
	m.add_theme_constant_override("margin_left", 10)
	m.add_theme_constant_override("margin_right", 10)
	m.add_theme_constant_override("margin_top", 10)
	m.add_theme_constant_override("margin_bottom", 10)
	card.add_child(m)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	m.add_child(v)
	return v

func _add_help(text: String) -> void:
	var p := _card()
	sheet_body.add_child(p)
	var v := _card_vbox(p)
	_add_small(v, text)

func _add_small(parent: Control, text: String) -> void:
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size", 10)
	l.add_theme_color_override("font_color", colors.muted)
	parent.add_child(l)

func _add_chips(parent: Control, values: Array) -> void:
	var flow := HFlowContainer.new()
	flow.add_theme_constant_override("h_separation", 4)
	flow.add_theme_constant_override("v_separation", 4)
	parent.add_child(flow)
	for value in values:
		var l := Label.new()
		l.text = str(value)
		l.add_theme_font_size_override("font_size", 8)
		l.add_theme_color_override("font_color", colors.ink)
		l.add_theme_stylebox_override("normal", _style(Color("#e8ddcb"), 7, Color.TRANSPARENT, 0))
		flow.add_child(l)

func _style_button(b: Button, primary: bool) -> void:
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", 10)
	b.add_theme_color_override("font_color", colors.ink)
	var bg: Color = Color("#f4e4c9") if primary else Color("#fffaf0")
	var border: Color = Color("#b88a52") if primary else colors.line
	b.add_theme_stylebox_override("normal", _style(bg, 9, border, 1))
	b.add_theme_stylebox_override("hover", _style(bg.lightened(0.03), 9, border, 1))
	b.add_theme_stylebox_override("pressed", _style(bg.darkened(0.05), 9, border, 1))
