class_name DomainData
extends RefCounted

static func district_points() -> Dictionary:
	return {
		"market": Vector2(0.14, 0.17),
		"bank": Vector2(0.50, 0.17),
		"media": Vector2(0.86, 0.17),
		"home": Vector2(0.14, 0.50),
		"tea": Vector2(0.50, 0.50),
		"factory": Vector2(0.86, 0.50),
		"school": Vector2(0.14, 0.83),
		"mall": Vector2(0.50, 0.83),
		"office": Vector2(0.86, 0.83),
	}

static func district_names() -> Dictionary:
	return {
		"market":"东门市场", "bank":"安泰银行", "media":"融媒体",
		"home":"幸福小区", "tea":"老街茶馆", "factory":"金海食品厂",
		"school":"城南小学", "mall":"商业街", "office":"新区写字楼"
	}

static func jobs_by_district() -> Dictionary:
	return {
		"market":["菜贩","批发商","摊主","饭店老板","水果商"],
		"bank":["银行柜员","客户经理","会计","保险业务员","证券员工"],
		"media":["本地记者","自媒体编辑","短视频主播","摄影师","剪辑师"],
		"home":["物业人员","退休职工","全职家长","护士","维修工"],
		"tea":["茶馆老板","棋牌室老板","退休干部","房产中介","自由职业者"],
		"factory":["食品厂工人","质检员","仓管员","供应商业务员","班组长"],
		"school":["小学老师","培训老师","家长","保安","校车司机"],
		"mall":["餐饮店长","外卖骑手","快递员","店员","服装店主"],
		"office":["程序员","销售经理","创业者","企业财务","行政","HR"]
	}

static func names() -> Array[String]:
	return [
		"张杰","王桂芬","李成海","赵美玲","陈国富","刘晓琴","杨志远","黄红霞",
		"周海峰","吴小军","徐一鸣","孙巧珍","胡国庆","朱建华","高敏","林雪",
		"何春生","郭强","马燕","罗凯","梁倩","宋文博","郑慧","谢蓉","韩磊",
		"唐霞","冯军","于芳","董明","萧静","程伟","曹涛","袁娜","邓勇",
		"许杰","傅娟","沈超","曾平","彭刚","吕洋","苏艳","卢敏","蒋军",
		"蔡勇","贾涛","丁芳","魏超","薛明","叶静","阎强","余娜","潘伟",
		"杜杰","戴敏","夏军","钟涛","汪芳","田勇","任杰","姜静","范明",
		"方伟","石涛","姚敏","谭军","廖芳","邹强","熊娜","金杰","陆敏",
		"秦文娟","孟超","白雪","顾一鸣","杜志强","高晓琴","蒋红霞","方磊"
	]

static func trait_pool() -> Array[String]:
	return ["谨慎","多疑","热心","冲动","爱面子","圆滑","悲观","乐观","怕麻烦","记仇","爱占便宜","重感情"]

static func social_pool() -> Array[String]:
	return ["爱发群聊","大嘴巴","嘴严","爱打电话","爱直播","只跟熟人说","喜欢添油加醋","会套话"]

static func intel_pool() -> Array[Dictionary]:
	return [
		{"id":"bank","domain":"finance","domain_label":"金融","subject":"安泰银行","seed":"liquidity","text":"最近大额取现似乎比平时多。","truth":0.55,"source":"银行员工家属","base_trace":9},
		{"id":"factory","domain":"factory","domain_label":"企业","subject":"金海食品厂","seed":"salary","text":"这个月工资可能要晚几天。","truth":0.70,"source":"厂区工人","base_trace":7},
		{"id":"subway","domain":"property","domain_label":"地产","subject":"东门片区","seed":"subway","text":"最近有人拿测量设备在附近走动。","truth":0.45,"source":"菜市场摊主","base_trace":5},
		{"id":"school","domain":"school","domain_label":"教育","subject":"城南小学","seed":"boundary","text":"下学期招生范围可能会调整。","truth":0.50,"source":"家长群截图","base_trace":12},
		{"id":"food","domain":"food","domain_label":"餐饮","subject":"老街饭馆","seed":"hidden_good","text":"有个本地大主播准备去探店。","truth":0.65,"source":"饭店员工","base_trace":6},
		{"id":"market","domain":"market","domain_label":"市场","subject":"东门市场","seed":"move","text":"有商户开始询问摊位转让。","truth":0.80,"source":"批发商","base_trace":4}
	]

static func domains() -> Dictionary:
	return {
		"finance": {
			"label":"金融",
			"districts":["bank","office","home","tea","media"],
			"roles":["银行柜员","客户经理","保险业务员","证券员工","会计","企业财务","创业者","本地记者","自媒体编辑"],
			"nodes":{
				"liquidity":{"label":"资金紧张","stage":1,"children":["withdrawal","credit"],"lines":["最近资金面看着有点紧","有人在盯流动性","周转似乎不太顺"]},
				"withdrawal":{"label":"大额取现增加","stage":2,"children":["queue","limit"],"lines":["这两天取大额现金的人多了","柜台明显更忙","有人提前来取钱"]},
				"credit":{"label":"授信收紧","stage":2,"children":["business_cash"],"lines":["企业贷款似乎卡得更严","续贷有人说不好批","授信口径像是收紧了"]},
				"queue":{"label":"储户排队","stage":3,"children":["limit","panic"],"lines":["网点门口开始有人排队","有人专门提前来取现","储户明显更紧张了"]},
				"limit":{"label":"取现审核加强","stage":3,"children":["panic"],"lines":["大额取现多一道审核","取大额现金要提前说","柜台对大额现金更谨慎"]},
				"business_cash":{"label":"企业现金流受压","stage":3,"children":["salary_delay"],"lines":["企业开始留现金","有老板担心续贷","公司财务更保守了"]},
				"salary_delay":{"label":"工资受影响","stage":4,"children":["panic"],"lines":["有人担心工资发放","企业员工开始问工资卡","资金一紧工资也被讨论"]},
				"panic":{"label":"挤兑恐慌","stage":4,"children":[],"lines":["有人已经担心钱取不出来","恐慌情绪明显起来了","越来越多人把它当成银行风险"]}
			}
		},
		"factory": {
			"label":"企业经营",
			"districts":["factory","office","home","tea","media"],
			"roles":["食品厂工人","质检员","仓管员","供应商业务员","班组长","企业财务","销售经理","本地记者"],
			"nodes":{
				"salary":{"label":"工资延迟","stage":1,"children":["worker_anxiety","supplier"],"lines":["这个月工资可能晚几天","财务还没定发薪时间","工人都在问工资"]},
				"worker_anxiety":{"label":"员工焦虑","stage":2,"children":["resign","gather"],"lines":["车间里已经有人慌了","不少人在问是不是经营出问题","有人开始看新工作"]},
				"supplier":{"label":"供应商催款","stage":2,"children":["cash_chain"],"lines":["供应商催得更紧了","外面的货款有人在追","对账时大家都更谨慎"]},
				"resign":{"label":"员工准备离职","stage":3,"children":["production"],"lines":["有人开始投简历","几个熟练工想走","车间里有离职风声"]},
				"gather":{"label":"员工集中问薪","stage":3,"children":["statement"],"lines":["有人去财务问说法","工人开始集中问工资","财务门口人多起来了"]},
				"cash_chain":{"label":"资金链担忧","stage":3,"children":["production","statement"],"lines":["有人担心整个资金链","如果货款也拖问题就大","公司周转可能有压力"]},
				"production":{"label":"停产传闻","stage":4,"children":["statement"],"lines":["已经有人猜会不会停线","生产安排也被讨论","可能会临时减产"]},
				"statement":{"label":"公司回应","stage":4,"children":[],"lines":["公司开始统一口径","管理层准备出说明","大家都等公司回应"]}
			}
		},
		"property": {
			"label":"地产规划",
			"districts":["market","home","tea","office","media"],
			"roles":["房产中介","物业人员","全职家长","退休职工","创业者","销售经理","本地记者","自媒体编辑"],
			"nodes":{
				"subway":{"label":"地铁规划","stage":1,"children":["measure","house_attention"],"lines":["东门可能进地铁规划","这边可能有站点","规划好像有动静"]},
				"measure":{"label":"现场测量","stage":2,"children":["station_guess"],"lines":["有人看见测量人员","附近有人拿设备测东西","有人说在做前期勘测"]},
				"house_attention":{"label":"房源关注增加","stage":2,"children":["owner_hold","rent"],"lines":["中介突然问东门房源","看房的人变多","有人提前看房"]},
				"station_guess":{"label":"站点位置猜测","stage":3,"children":["owner_hold","rent"],"lines":["大家都在猜站口位置","有人说可能靠近市场","具体位置还没人说准"]},
				"owner_hold":{"label":"房东惜售","stage":3,"children":["price"],"lines":["有房东不着急卖了","几个房源突然撤牌","有人想等消息明朗"]},
				"rent":{"label":"租金预期上升","stage":3,"children":["price"],"lines":["房东开始谈涨租","商铺租金也有人问","租客开始担心租金"]},
				"price":{"label":"价格上涨预期","stage":4,"children":[],"lines":["报价已经有人往上加","大家开始按涨价谈","预期起来价格就变了"]}
			}
		},
		"school": {
			"label":"教育学区",
			"districts":["school","home","tea","media","office"],
			"roles":["小学老师","培训老师","家长","校车司机","物业人员","全职家长","本地记者","自媒体编辑"],
			"nodes":{
				"boundary":{"label":"学区调整","stage":1,"children":["parent_chat","transfer"],"lines":["学区可能要调整","家长群说边界可能变","下学期招生范围可能变化"]},
				"parent_chat":{"label":"家长群发酵","stage":2,"children":["transfer","house_school"],"lines":["家长群已经聊开了","好几个家长都在问","大家开始转截图"]},
				"transfer":{"label":"转学咨询增加","stage":3,"children":["house_school"],"lines":["已经有人问转学","家长开始做备选","培训机构也在打听"]},
				"house_school":{"label":"学区房预期","stage":4,"children":[],"lines":["附近房源开始拿学区说事","中介拿招生范围做话术","有家长提前看房"]}
			}
		},
		"food": {
			"label":"餐饮口碑",
			"districts":["mall","market","tea","home","media"],
			"roles":["饭店老板","餐饮店长","外卖骑手","短视频主播","自媒体编辑","全职家长","本地记者"],
			"nodes":{
				"hidden_good":{"label":"小店口碑","stage":1,"children":["creator_visit","queue"],"lines":["老街那家店其实挺好吃","几个熟客都在夸","那家店被低估了"]},
				"creator_visit":{"label":"博主探店","stage":2,"children":["queue","booking"],"lines":["有博主要去拍","已经有人发探店视频","店里来了拍视频的人"]},
				"queue":{"label":"排队增加","stage":3,"children":["booking","price_up"],"lines":["门口开始排队","饭点得等位","客流明显多了"]},
				"booking":{"label":"预约爆满","stage":3,"children":["price_up"],"lines":["周末位置都有人提前订","临时去不一定吃得上","预约越来越多"]},
				"price_up":{"label":"涨价讨论","stage":4,"children":[],"lines":["有人问老板会不会涨价","爆火后价格也被讨论","周边店都盯着定价"]}
			}
		},
		"market": {
			"label":"市场经营",
			"districts":["market","tea","home","media","mall"],
			"roles":["菜贩","批发商","摊主","水果商","饭店老板","外卖骑手","本地记者","自媒体编辑"],
			"nodes":{
				"move":{"label":"市场搬迁","stage":1,"children":["stall_transfer","merchant_wait"],"lines":["市场有搬迁风声","有人说可能调整位置","最近有人问摊位怎么办"]},
				"stall_transfer":{"label":"摊位转让增加","stage":2,"children":["dump_goods"],"lines":["问摊位转让的人变多","有人想先把摊位出掉","摊位价格开始有人压"]},
				"merchant_wait":{"label":"商户观望","stage":2,"children":["dump_goods","rent_change"],"lines":["商户先不签长合同","大家都在等消息","进货开始保守"]},
				"dump_goods":{"label":"商户甩货","stage":3,"children":["rent_change"],"lines":["有人加快清库存","低价甩货变多","有人怕搬迁压货"]},
				"rent_change":{"label":"周边租金波动","stage":4,"children":[],"lines":["周边铺租开始重新谈","房东和商户拉扯租金","租金预期被带动"]}
			}
		}
	}

static func role_speech() -> Dictionary:
	return {
		"银行柜员":{"prefix":["柜面这边最近有点变化","我今天柜台上看着确实不太一样","我们这边有人在议论"],"suffix":["但具体原因我不敢乱说","先别往外传","到底是不是一回事还得看"]},
		"客户经理":{"prefix":["我这两天接企业电话挺多","最近客户都在问同一件事","我手里几个客户都开始紧张"],"suffix":["这事要是真发酵会影响贷款","企业那边会先有感觉","最怕客户一起反应"]},
		"本地记者":{"prefix":["目前我只拿到一条线索","我还没找到第二个来源","这个说法现在只能算传闻"],"suffix":["没有交叉验证我不会下结论","得先找当事方回应","消息源还不够硬"]},
		"自媒体编辑":{"prefix":["这条要是发出去肯定有人点","本地群里已经有人聊","这个话题很容易起量"],"suffix":["标题一换热度会更高","就看有没有证据撑住","一旦有人跟拍就会爆"]},
		"短视频主播":{"prefix":["我刚收到一个本地消息","这个事现在很有讨论度","家人们我先说个我听到的"],"suffix":["先别急着当真","评论区有人知道内情吗","我准备去现场看看"]},
		"房产中介":{"prefix":["最近客户问得有点反常","这两天房东态度明显不一样","我手里几个房源都有变化"],"suffix":["预期一起来报价马上就变","现在最敏感的是房东","先看成交量会不会动"]},
		"小学老师":{"prefix":["家长群里已经有人问了","学校这边暂时没统一通知","老师办公室里也有人讨论"],"suffix":["没正式文件不能当真","家长最容易先焦虑","招生口径才是关键"]},
		"食品厂工人":{"prefix":["车间里现在都在问","今天班组里一直有人聊","我听同事说"],"suffix":["最怕影响工资","大家现在心里没底","先看明天班次怎么排"]},
		"供应商业务员":{"prefix":["我这边最关心回款","最近对账时感觉不太对","外面的供应商已经有人问"],"suffix":["账期一变就说明有问题","我得先保自己的货款","这个比传言本身更重要"]},
		"菜贩":{"prefix":["市场里今天都在说","我隔壁摊刚跟我提","这两天摊主之间都在问"],"suffix":["真搬的话进货就得少点","先看摊位有没有人转","我可不敢压太多货"]},
		"全职家长":{"prefix":["家长群里有人截了图","我刚听另一个家长说","小区里都有人聊"],"suffix":["孩子的事谁都不敢赌","我还是得先打电话问","没有通知我也不放心"]},
		"退休职工":{"prefix":["这种消息以前我也见过","楼下已经有人议论","我听老同事提了一嘴"],"suffix":["先别自己吓自己","真有事总会有正式说法","不过大家一慌就容易出事"]},
		"default":{"prefix":["我刚听到一个说法","有人在聊这个事","刚刚有人跟我提了一嘴","我也不知道真假"],"suffix":["你先听听别急着信","到底怎么回事还不好说","反正现在已经有人议论","我也是转述"]}
	}
